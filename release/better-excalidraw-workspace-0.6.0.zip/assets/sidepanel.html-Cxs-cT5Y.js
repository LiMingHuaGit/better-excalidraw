(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const n of document.querySelectorAll('link[rel="modulepreload"]'))s(n);new MutationObserver(n=>{for(const i of n)if(i.type==="childList")for(const f of i.addedNodes)f.tagName==="LINK"&&f.rel==="modulepreload"&&s(f)}).observe(document,{childList:!0,subtree:!0});function r(n){const i={};return n.integrity&&(i.integrity=n.integrity),n.referrerPolicy&&(i.referrerPolicy=n.referrerPolicy),n.crossOrigin==="use-credentials"?i.credentials="include":n.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function s(n){if(n.ep)return;n.ep=!0;const i=r(n);fetch(n.href,i)}})();const O="better-excalidraw-workspace",q=1,v="settings",A="workspace-directory-handle";function C(){return new Promise((e,t)=>{const r=indexedDB.open(O,q);r.onerror=()=>t(r.error),r.onupgradeneeded=()=>{r.result.objectStoreNames.contains(v)||r.result.createObjectStore(v)},r.onsuccess=()=>e(r.result)})}async function _(e){const t=await C();try{await new Promise((r,s)=>{const n=t.transaction(v,"readwrite");n.objectStore(v).put(e,A),n.oncomplete=()=>r(),n.onerror=()=>s(n.error),n.onabort=()=>s(n.error)})}finally{t.close()}}async function R(){const e=await C();try{return await new Promise((t,r)=>{const n=e.transaction(v,"readonly").objectStore(v).get(A);n.onsuccess=()=>t(n.result??null),n.onerror=()=>r(n.error)})}finally{e.close()}}const P=30,x=5,T=3600,$="autosaveSeconds",a={directory:null,canvases:[],activePath:null,filter:"",busy:!1,status:"请选择一个包含 .excalidraw 文件的目录",permissionRequired:!1,autosaveSeconds:P,createDialogOpen:!1,newCanvasName:"",newCanvasError:""};let m=null,g=null,E=!1;function M(){const e=document.querySelector("#app");if(!e)throw new Error("Missing app root");return e}const l=M();function c(e){const t=document.createElement("span");return t.textContent=e,t.innerHTML}function W(e){return e<1024?`${e} B`:e<1024*1024?`${(e/1024).toFixed(1)} KB`:`${(e/1024/1024).toFixed(1)} MB`}function B(e){return new Intl.DateTimeFormat("zh-CN",{month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit"}).format(e)}function h(e){return`<svg viewBox="0 0 20 20" aria-hidden="true">${{folder:'<path d="M3.5 6.25A1.75 1.75 0 0 1 5.25 4.5h3.02l1.5 1.75h5.98A1.75 1.75 0 0 1 17.5 8v6.75a1.75 1.75 0 0 1-1.75 1.75H5.25a1.75 1.75 0 0 1-1.75-1.75v-8.5Z"/>',refresh:'<path d="M16.5 6.5v-3m0 0h-3m3 0-2.15 2.15a6.5 6.5 0 1 0 1.38 7.1"/>',save:'<path d="M4 3.5h9.8L17 6.7v9.8H4v-13Z"/><path d="M7 3.5v5h7v-5M7 16.5v-5h7v5"/>',search:'<circle cx="9" cy="9" r="5.5"/><path d="m13 13 4 4"/>',canvas:'<rect x="3.5" y="3.5" width="13" height="13" rx="2"/><path d="m6.5 12 2.6-2.7 2.1 2 1.6-1.5 2.2 2.2"/>'}[e]}</svg>`}function u(){const e=a.filter.trim().toLocaleLowerCase(),t=a.canvases.filter(s=>s.relativePath.toLocaleLowerCase().includes(e)),r=a.directory?.name??"未选择工作区";l.innerHTML=`
    <main class="shell">
      <header class="header">
        <div class="brand-mark">B</div>
        <div class="brand-copy">
          <h1>Better Excalidraw</h1>
          <p>本地画布工作区</p>
        </div>
      </header>

      <section class="workspace-card">
        <div class="workspace-heading">
          <div class="workspace-icon">${h("folder")}</div>
          <div class="workspace-copy">
            <strong title="${c(r)}">${c(r)}</strong>
            <span>${a.canvases.length} 个画布</span>
          </div>
        </div>
        <button class="primary-button" data-action="choose-workspace" ${a.busy?"disabled":""}>
          ${a.directory?"更换目录":"打开工作区目录"}
        </button>
        <button class="secondary-button" data-action="new-canvas" ${!a.directory||a.busy?"disabled":""}>
          新建画布
        </button>
        ${a.permissionRequired?'<button class="secondary-button" data-action="reconnect">重新授权目录</button>':""}
      </section>

      <section class="toolbar" aria-label="画布工具栏">
        <label class="search-field">
          ${h("search")}
          <input type="search" placeholder="搜索画布" value="${c(a.filter)}" data-role="search" />
        </label>
        <button class="icon-button" title="重新扫描" aria-label="重新扫描" data-action="refresh" ${!a.directory||a.busy?"disabled":""}>
          ${h("refresh")}
        </button>
        <button class="icon-button" title="保存当前画布" aria-label="保存当前画布" data-action="save" ${!a.activePath||a.busy?"disabled":""}>
          ${h("save")}
        </button>
      </section>

      <section class="autosave-settings" aria-label="自动保存设置">
        <label for="autosave-seconds">自动保存</label>
        <input
          id="autosave-seconds"
          data-role="autosave-seconds"
          type="number"
          min="0"
          max="${T}"
          step="5"
          value="${a.autosaveSeconds}"
          aria-describedby="autosave-hint"
        />
        <span>秒</span>
        <small id="autosave-hint">0 为关闭，最短 ${x} 秒</small>
      </section>

      <section class="canvas-list" aria-label="工作区画布">
        ${t.length?t.map(s=>`
                    <button class="canvas-row ${a.activePath===s.relativePath?"active":""}" data-canvas-path="${c(s.relativePath)}" ${a.busy?"disabled":""}>
                      <span class="canvas-icon">${h("canvas")}</span>
                      <span class="canvas-copy">
                        <strong>${c(s.name.replace(/\.excalidraw$/i,""))}</strong>
                        <small>${c(s.relativePath)} · ${W(s.size)} · ${B(s.modifiedAt)}</small>
                      </span>
                    </button>
                  `).join(""):`<div class="empty-state">${a.directory?e?"没有匹配的画布":"目录中没有 .excalidraw 文件":"打开一个目录后，画布会显示在这里"}</div>`}
      </section>

      <footer class="status ${a.busy?"busy":""}">
        <span class="status-dot"></span>
        <span>${c(a.status)}</span>
      </footer>
      ${a.createDialogOpen?`<div class="dialog-backdrop" data-role="dialog-backdrop">
              <form class="create-dialog" data-role="new-canvas-form">
                <h2>新建画布</h2>
                <p>画布将保存到当前工作区根目录。</p>
                <label>
                  <span>画布名称</span>
                  <input data-role="new-canvas-name" value="${c(a.newCanvasName)}" autocomplete="off" autofocus />
                </label>
                ${a.newCanvasError?`<p class="dialog-error" role="alert">${c(a.newCanvasError)}</p>`:""}
                <div class="dialog-actions">
                  <button type="button" class="dialog-button" data-action="cancel-new-canvas">取消</button>
                  <button type="submit" class="dialog-button primary">创建</button>
                </div>
              </form>
            </div>`:""}
    </main>
  `}function o(e,t=!1){a.status=e,a.busy=t,u()}async function N(){try{await navigator.storage?.persist?.()}catch{}}async function p(e,t){const r={mode:"readwrite"};return await e.queryPermission(r)==="granted"?!0:t?await e.requestPermission(r)==="granted":!1}async function L(e,t=""){const r=[];for await(const[s,n]of e.entries()){if(s.startsWith("."))continue;const i=t?`${t}/${s}`:s;if(n.kind==="directory"){r.push(...await L(n,i));continue}if(!s.toLocaleLowerCase().endsWith(".excalidraw"))continue;const f=await n.getFile();r.push({name:s,relativePath:i,handle:n,size:f.size,modifiedAt:f.lastModified})}return r.sort((s,n)=>s.relativePath.localeCompare(n.relativePath,"zh-CN"))}async function w(){if(a.directory){o("正在扫描工作区…",!0);try{if(!await p(a.directory,!1)){a.permissionRequired=!0,a.canvases=[],o("需要重新授权才能读取工作区");return}a.permissionRequired=!1,a.canvases=await L(a.directory),a.activePath&&!a.canvases.some(e=>e.relativePath===a.activePath)&&(a.activePath=null),o(`已读取 ${a.canvases.length} 个画布`)}catch(e){o(`扫描失败：${e instanceof Error?e.message:String(e)}`)}}}async function F(){try{const e=await window.showDirectoryPicker({id:"better-excalidraw-workspace",mode:"readwrite",startIn:a.directory??"documents"});a.directory=e,a.activePath=null,a.permissionRequired=!1,await _(e),await N(),await w()}catch(e){if(e instanceof DOMException&&e.name==="AbortError")return;o(`打开目录失败：${e instanceof Error?e.message:String(e)}`)}}function I(){const e=new Set(a.canvases.map(r=>r.name.replace(/\.excalidraw$/i,"")));let t=1;for(;e.has(t===1?"未命名画布":`未命名画布 ${t}`);)t+=1;return t===1?"未命名画布":`未命名画布 ${t}`}function H(){a.newCanvasName=I(),a.newCanvasError="",a.createDialogOpen=!0,u(),window.requestAnimationFrame(()=>{const e=l.querySelector("[data-role='new-canvas-name']");e?.focus(),e?.select()})}function S(){a.createDialogOpen=!1,a.newCanvasName="",a.newCanvasError="",u()}function d(e){a.newCanvasError=e,u(),window.requestAnimationFrame(()=>{l.querySelector("[data-role='new-canvas-name']")?.focus()})}async function V(){if(!a.directory)return;const e=a.newCanvasName.trim();if(!e){d("请输入画布名称");return}if(/[\\/:*?\"<>|\0]/.test(e)){d('画布名称不能包含 \\ / : * ? " < > | 等字符');return}if(e.startsWith(".")){d("画布名称不能以 . 开头");return}const t=e.toLocaleLowerCase().endsWith(".excalidraw")?e:`${e}.excalidraw`;try{if(!await p(a.directory,!0)){d("没有工作区写入权限");return}try{await a.directory.getFileHandle(t),d("工作区中已存在同名画布");return}catch(n){if(!(n instanceof DOMException&&n.name==="NotFoundError"))throw n}if(a.createDialogOpen=!1,a.newCanvasError="",u(),a.activePath&&!await b({quiet:!0,refresh:!1,displayLoading:!0,loadingText:"正在保存当前画布…"})){a.createDialogOpen=!0,a.newCanvasName=e,d("当前画布保存失败，尚未创建新画布");return}o(`正在创建 ${t}…`,!0);const s=await(await a.directory.getFileHandle(t,{create:!0})).createWritable();try{await s.write(JSON.stringify({type:"excalidraw",version:2,source:"https://excalidraw.com",elements:[],appState:{viewBackgroundColor:"#ffffff"},files:{}},null,2)),await s.close()}catch(n){throw await s.abort().catch(()=>{}),n}a.activePath=null,g=null,await w(),await D(t)}catch(r){const s=`创建失败：${r instanceof Error?r.message:String(r)}`;a.createDialogOpen?d(s):o(s)}}async function U(){const t=(await chrome.tabs.query({active:!0,currentWindow:!0}))[0];if(!t?.id||!t.url?.startsWith("https://excalidraw.com/"))throw new Error("请先打开并选中 excalidraw.com 页面");return t}async function y(e){const t=await U();return chrome.tabs.sendMessage(t.id,e)}async function D(e){const t=a.canvases.find(r=>r.relativePath===e);if(t&&t.relativePath!==a.activePath&&!(a.activePath&&!await b({quiet:!0,refresh:!1,displayLoading:!0,loadingText:"正在保存并切换画布…"}))){o(`正在加载 ${t.name}…`,!0);try{const s=await(await t.handle.getFile()).text(),n=await y({type:"BETTER_EXCALIDRAW_LOAD_CANVAS",fileName:t.name,content:s});if(!n.ok)throw new Error(n.error);a.activePath=t.relativePath,g=n.content??s,o(`已打开 ${t.name}`)}catch(r){o(`加载失败：${r instanceof Error?r.message:String(r)}`)}}}async function b(e={}){const t=a.canvases.find(r=>r.relativePath===a.activePath);if(!t||!a.directory)return!0;if(a.busy||E)return!1;E=!0,e.quiet||o(`正在保存 ${t.name}…`,!0);try{if(e.displayLoading){const n=await y({type:"BETTER_EXCALIDRAW_SET_SAVE_STATUS",visible:!0,text:e.loadingText});if(!n.ok)throw new Error(n.error)}if(!await p(a.directory,!0))throw new Error("没有工作区写入权限");const r=await y({type:"BETTER_EXCALIDRAW_CAPTURE_CANVAS"});if(!r.ok)throw new Error(r.error);if(!r.content)throw new Error("没有读取到当前画布内容");if(r.content===g)return e.quiet||o(`${t.name} 没有未保存修改`),!0;const s=await t.handle.createWritable();return await s.write(r.content),await s.close(),g=r.content,e.refresh!==!1&&await w(),o(`${e.quiet?"已自动保存":"已保存"} ${t.name}`),!0}catch(r){return o(`保存失败：${r instanceof Error?r.message:String(r)}`),!1}finally{if(e.displayLoading)try{await y({type:"BETTER_EXCALIDRAW_SET_SAVE_STATUS",visible:!1})}catch{}E=!1}}function k(){m!==null&&(window.clearInterval(m),m=null),a.autosaveSeconds!==0&&(m=window.setInterval(()=>{!a.activePath||a.busy||b({quiet:!0,refresh:!1})},a.autosaveSeconds*1e3))}async function z(e){const t=Number.parseInt(e,10),r=Number.isFinite(t)?t===0?0:Math.min(T,Math.max(x,t)):P;a.autosaveSeconds=r,await chrome.storage.local.set({[$]:r}),k(),o(r===0?"已关闭自动保存":`每 ${r} 秒自动保存`)}async function K(){const t=(await chrome.storage.local.get($))[$];typeof t=="number"&&t>=0&&(a.autosaveSeconds=t),k()}async function X(){if(a.directory)try{if(!await p(a.directory,!0)){o("未获得目录授权");return}a.permissionRequired=!1,await w()}catch(e){o(`授权失败：${e instanceof Error?e.message:String(e)}`)}}l.addEventListener("click",e=>{const t=e.target;if(t.dataset.role==="dialog-backdrop"){S();return}const r=t.closest("[data-action]"),s=t.closest("[data-canvas-path]");if(s?.dataset.canvasPath){D(s.dataset.canvasPath);return}switch(r?.dataset.action){case"choose-workspace":F();break;case"reconnect":X();break;case"new-canvas":H();break;case"cancel-new-canvas":S();break;case"refresh":w();break;case"save":b({displayLoading:!0,loadingText:"正在保存当前画布…"});break}});l.addEventListener("input",e=>{const t=e.target;if(t.dataset.role==="new-canvas-name"){a.newCanvasName=t.value;return}if(t.dataset.role!=="search")return;a.filter=t.value,u();const r=l.querySelector("[data-role='search']");r?.focus(),r?.setSelectionRange(a.filter.length,a.filter.length)});l.addEventListener("submit",e=>{e.target.dataset.role==="new-canvas-form"&&(e.preventDefault(),V())});l.addEventListener("change",e=>{const t=e.target;t.dataset.role==="autosave-seconds"&&z(t.value)});async function j(){u();try{await K(),u();const e=await R();if(!e)return;if(a.directory=e,await N(),!await p(e,!1)){a.permissionRequired=!0,o("Chrome 安全限制：请点击“重新授权目录”恢复上次工作区，无需重新选择目录");return}await w()}catch(e){o(`恢复工作区失败：${e instanceof Error?e.message:String(e)}`)}}j();
//# sourceMappingURL=sidepanel.html-Cxs-cT5Y.js.map
