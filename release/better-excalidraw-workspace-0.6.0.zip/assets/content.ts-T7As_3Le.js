(function(){const b=(e,n=!1)=>({type:"line",points:[...e,e[0]],closed:!0,round:n}),k=(e,n=!1)=>({type:"line",points:e,round:n}),de={triangle:[b([[90,0],[180,180],[0,180]])],rightTriangle:[b([[0,0],[180,180],[0,180]])],pentagon:[b([[90,0],[180,69],[146,180],[34,180],[0,69]])],hexagon:[b([[45,0],[135,0],[180,90],[135,180],[45,180],[0,90]])],trapezoid:[b([[45,0],[135,0],[180,180],[0,180]])],parallelogram:[b([[45,0],[180,0],[135,180],[0,180]])],star:[b([[90,0],[111,62],[176,62],[123,101],[144,164],[90,126],[36,164],[57,101],[4,62],[69,62]])],chevron:[b([[0,0],[110,0],[180,90],[110,180],[0,180],[70,90]])],speechBubble:[b([[25,15],[155,15],[175,35],[175,115],[155,135],[105,135],[80,170],[68,135],[25,135],[5,115],[5,35]],!0)],plus:[b([[60,0],[120,0],[120,60],[180,60],[180,120],[120,120],[120,180],[60,180],[60,120],[0,120],[0,60],[60,60]])],pie:[{type:"ellipse",x:0,y:0,width:180,height:180},k([[90,90],[90,0]]),k([[90,90],[180,90]])],cube:[b([[0,45],[125,45],[125,180],[0,180]]),b([[0,45],[55,0],[180,0],[125,45]]),b([[125,45],[180,0],[180,135],[125,180]])],leftArrow:[b([[0,90],[70,20],[70,60],[180,60],[180,120],[70,120],[70,160]])],rightArrow:[b([[180,90],[110,20],[110,60],[0,60],[0,120],[110,120],[110,160]])],doubleArrow:[b([[0,90],[55,25],[55,60],[125,60],[125,25],[180,90],[125,155],[125,120],[55,120],[55,155]])],decision:[b([[90,0],[180,90],[90,180],[0,90]])],process:[b([[0,0],[180,0],[180,180],[0,180]]),k([[35,0],[35,180]]),k([[145,0],[145,180]])],internalStorage:[b([[0,0],[180,0],[180,180],[0,180]]),k([[35,0],[35,180]]),k([[0,35],[180,35]])],offPageConnector:[b([[0,0],[180,0],[180,120],[90,180],[0,120]])],card:[b([[0,0],[135,0],[180,45],[180,180],[0,180]]),k([[135,0],[135,45],[180,45]])]};function te(){return crypto.randomUUID().replaceAll("-","").slice(0,20)}function F(){return Math.floor(Math.random()*2e9)+1}function ne(e,n){return{id:te(),angle:0,strokeColor:e.currentItemStrokeColor??"#1e1e1e",fillStyle:e.currentItemFillStyle??"solid",strokeWidth:e.currentItemStrokeWidth??2,strokeStyle:e.currentItemStrokeStyle??"solid",roughness:e.currentItemRoughness??1,opacity:e.currentItemOpacity??100,groupIds:n,frameId:null,seed:F(),version:1,versionNonce:F(),isDeleted:!1,boundElements:[],updated:Date.now(),created:Date.now(),link:null,locked:!1}}function ue(e,n,o,t,r){const a=Math.min(...e.points.map(([d])=>d)),c=Math.min(...e.points.map(([,d])=>d)),l=Math.max(...e.points.map(([d])=>d)),u=Math.max(...e.points.map(([,d])=>d)),m=e.points.map(([d,g])=>[(d-a)/180*o,(g-c)/180*t]);return{...ne(n,r),type:"line",x:a/180*o,y:c/180*t,width:(l-a)/180*o,height:(u-c)/180*t,backgroundColor:e.closed?n.currentItemBackgroundColor??"transparent":"transparent",roundness:e.round?{type:2}:null,points:m,lastCommittedPoint:null,startBinding:null,endBinding:null,startArrowhead:null,endArrowhead:null,elbowed:!1,polygon:e.closed===!0}}function pe(e,n,o,t,r){return{...ne(n,r),type:"ellipse",x:e.x/180*o,y:e.y/180*t,width:e.width/180*o,height:e.height/180*t,backgroundColor:n.currentItemBackgroundColor??"transparent",roundness:null}}function me(e,n,o,t){const r=Math.max(1,o),a=Math.max(1,t),c=de[e],l=c.length>1?[te()]:[];return c.map(u=>u.type==="ellipse"?pe(u,n,r,a,l):ue(u,n,r,a,l))}const K="better-excalidraw-page-ui-styles",B="better-excalidraw-workspace-button",h="better-excalidraw-shapes-button",y="better-excalidraw-shapes-panel",x="better-excalidraw-operations-button",E="better-excalidraw-operations-panel",Y="better-excalidraw-page-toast",M="better-excalidraw-draw-preview",O="better-excalidraw-draw-hint",oe=[{label:"基础",shapes:[{kind:"triangle",label:"三角形",icon:'<polygon points="12,3 21,21 3,21"/>'},{kind:"rightTriangle",label:"直角三角形",icon:'<polygon points="4,3 21,21 4,21"/>'},{kind:"pentagon",label:"五边形",icon:'<polygon points="12,2 22,9 18,21 6,21 2,9"/>'},{kind:"hexagon",label:"六边形",icon:'<polygon points="6,3 18,3 23,12 18,21 6,21 1,12"/>'},{kind:"trapezoid",label:"梯形",icon:'<polygon points="7,3 17,3 22,21 2,21"/>'},{kind:"parallelogram",label:"平行四边形",icon:'<polygon points="7,3 22,3 17,21 2,21"/>'},{kind:"star",label:"星形",icon:'<polygon points="12,2 14.5,9 22,9 16,13.5 18.5,21 12,16.5 5.5,21 8,13.5 2,9 9.5,9"/>'},{kind:"chevron",label:"箭头形",icon:'<polygon points="3,3 14,3 22,12 14,21 3,21 11,12"/>'},{kind:"speechBubble",label:"气泡",icon:'<path d="M4 4h16v12H12l-4 4v-4H4Z"/>'},{kind:"plus",label:"加号",icon:'<polygon points="9,2 15,2 15,9 22,9 22,15 15,15 15,22 9,22 9,15 2,15 2,9 9,9"/>'},{kind:"pie",label:"饼图",icon:'<circle cx="12" cy="12" r="9"/><path class="shape-detail" d="M12 12V3m0 9h9"/>'},{kind:"cube",label:"立方体",icon:'<path d="m4 7 8-4 8 4v10l-8 4-8-4Z"/><path class="shape-detail" d="m4 7 8 4 8-4M12 11v10"/>'}]},{label:"箭头",shapes:[{kind:"leftArrow",label:"左箭头",icon:'<polygon points="2,12 10,4 10,9 22,9 22,15 10,15 10,20"/>'},{kind:"rightArrow",label:"右箭头",icon:'<polygon points="22,12 14,4 14,9 2,9 2,15 14,15 14,20"/>'},{kind:"doubleArrow",label:"双向箭头",icon:'<polygon points="2,12 8,5 8,9 16,9 16,5 22,12 16,19 16,15 8,15 8,19"/>'}]},{label:"流程图",shapes:[{kind:"decision",label:"选择/判断",icon:'<polygon points="12,2 22,12 12,22 2,12"/>'},{kind:"process",label:"预定义流程",icon:'<rect x="3" y="3" width="18" height="18"/><path class="shape-detail" d="M7 3v18M17 3v18"/>'},{kind:"internalStorage",label:"内部存储",icon:'<rect x="3" y="3" width="18" height="18"/><path class="shape-detail" d="M7 3v18M3 7h18"/>'},{kind:"offPageConnector",label:"离页连接符",icon:'<polygon points="3,3 21,3 21,15 12,21 3,15"/>'},{kind:"card",label:"卡片",icon:'<path d="M3 3h13l5 5v13H3Z"/><path class="shape-detail" d="M16 3v5h5"/>'}]}],be=oe.flatMap(e=>e.shapes),he=[{operation:"duplicate",label:"复制一份",shortcut:"Ctrl/⌘ D",icon:'<rect x="7" y="7" width="11" height="11" rx="2"/><path d="M15 7V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>'},{operation:"rotateClockwise",label:"顺时针旋转 90°",icon:'<path d="M19 8V3m0 0h-5m5 0-3.2 3.2A8 8 0 1 0 20 13"/>'},{operation:"rotateCounterclockwise",label:"逆时针旋转 90°",icon:'<path d="M5 8V3m0 0h5M5 3l3.2 3.2A8 8 0 1 1 4 13"/>'},{operation:"flipHorizontal",label:"水平翻转",shortcut:"Shift H",icon:'<path d="M12 3v18M9 5 3 9v6l6 4V5Zm6 0 6 4v6l-6 4V5Z"/>'},{operation:"flipVertical",label:"垂直翻转",shortcut:"Shift V",icon:'<path d="M3 12h18M5 9l4-6h6l4 6H5Zm0 6 4 6h6l4-6H5Z"/>'}];function fe(){return`
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M3.5 6.5A2 2 0 0 1 5.5 4.5h4l2 2h7A2 2 0 0 1 20.5 8.5v9A2 2 0 0 1 18.5 19.5h-13a2 2 0 0 1-2-2v-11Z"/>
      <path d="M7 11h10M7 15h7"/>
    </svg>`}function ge(){return`
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="m7 3 5 8H2l5-8Z"/>
      <rect x="13.5" y="3.5" width="7" height="7" rx="1"/>
      <circle cx="16.5" cy="17" r="4"/>
    </svg>`}function xe(){return`
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <circle cx="5" cy="12" r="1.5"/>
      <circle cx="12" cy="12" r="1.5"/>
      <circle cx="19" cy="12" r="1.5"/>
    </svg>`}function re(e){return`<svg viewBox="0 0 24 24" aria-hidden="true">${e}</svg>`}function we(){if(document.getElementById(K))return;const e=document.createElement("style");e.id=K,e.textContent=`
    .better-excalidraw-page-button {
      position: fixed;
      z-index: 20;
      width: 40px;
      height: 40px;
      display: grid;
      place-items: center;
      padding: 0;
      border: 0;
      border-radius: 10px;
      color: var(--icon-fill-color, #1b1b1f);
      background: var(--island-bg-color, #fff);
      box-shadow: var(--shadow-island, 0 1px 4px rgba(0, 0, 0, 0.18));
      cursor: pointer;
      transition: background-color 120ms ease, color 120ms ease, transform 120ms ease;
    }
    .better-excalidraw-page-button:hover {
      color: var(--color-primary, #6965db);
      background: var(--button-hover-bg, #f1f0ff);
    }
    .better-excalidraw-page-button:active { transform: scale(.96); }
    .better-excalidraw-page-button:focus-visible {
      outline: 2px solid var(--color-primary, #6965db);
      outline-offset: 2px;
    }
    .better-excalidraw-page-button svg {
      width: 22px;
      height: 22px;
      fill: none;
      stroke: currentColor;
      stroke-width: 1.7;
      stroke-linecap: round;
      stroke-linejoin: round;
    }
    #${B} { top: 68px; left: 16px; }
    #${h} { top: 12px; right: 62px; }
    #${x} { top: 12px; right: 16px; }
    #${h}[aria-expanded="true"] {
      color: var(--color-primary, #6965db);
      background: var(--button-active-bg, #e9e7ff);
    }
    #${h}[aria-pressed="true"] {
      color: var(--color-primary, #6965db);
      background: var(--button-active-bg, #e9e7ff);
    }
    #${y} {
      position: fixed;
      z-index: 21;
      width: 310px;
      max-height: min(620px, calc(100vh - 90px));
      overflow-y: auto;
      padding: 10px;
      border: 1px solid var(--default-border-color, rgba(0, 0, 0, .12));
      border-radius: 12px;
      color: var(--text-primary-color, #1b1b1f);
      background: var(--island-bg-color, #fff);
      box-shadow: var(--shadow-island, 0 6px 24px rgba(0, 0, 0, .18));
      animation: better-excalidraw-panel-in 120ms ease-out;
    }
    #${x}[aria-expanded="true"] {
      color: var(--color-primary, #6965db);
      background: var(--button-active-bg, #e9e7ff);
    }
    #${E} {
      position: fixed;
      z-index: 21;
      width: 230px;
      padding: 7px;
      border: 1px solid var(--default-border-color, rgba(0, 0, 0, .12));
      border-radius: 12px;
      color: var(--text-primary-color, #1b1b1f);
      background: var(--island-bg-color, #fff);
      box-shadow: var(--shadow-island, 0 6px 24px rgba(0, 0, 0, .18));
      animation: better-excalidraw-panel-in 120ms ease-out;
    }
    @keyframes better-excalidraw-panel-in {
      from { opacity: 0; transform: translateY(-4px) scale(.98); }
      to { opacity: 1; transform: translateY(0) scale(1); }
    }
    .better-excalidraw-shape-heading {
      margin: 5px 4px 7px;
      color: var(--text-secondary-color, #6b6b73);
      font: 600 12px/16px system-ui, sans-serif;
    }
    .better-excalidraw-shape-grid {
      display: grid;
      grid-template-columns: repeat(5, 1fr);
      gap: 6px;
      margin-bottom: 10px;
    }
    .better-excalidraw-shape-option {
      min-width: 0;
      height: 50px;
      display: grid;
      place-items: center;
      padding: 0;
      border: 0;
      border-radius: 8px;
      color: var(--icon-fill-color, #1b1b1f);
      background: transparent;
      cursor: pointer;
    }
    .better-excalidraw-shape-option:hover,
    .better-excalidraw-shape-option:focus-visible {
      color: var(--color-primary, #6965db);
      background: var(--button-hover-bg, #f1f0ff);
      outline: 0;
    }
    .better-excalidraw-shape-option svg {
      width: 28px;
      height: 28px;
      fill: none;
      stroke: currentColor;
      stroke-width: 1.6;
      stroke-linejoin: round;
    }
    .better-excalidraw-operation-option {
      width: 100%;
      min-height: 38px;
      display: grid;
      grid-template-columns: 24px 1fr auto;
      align-items: center;
      gap: 9px;
      padding: 7px 9px;
      border: 0;
      border-radius: 8px;
      color: inherit;
      background: transparent;
      cursor: pointer;
      text-align: left;
      font: 500 13px/18px system-ui, sans-serif;
    }
    .better-excalidraw-operation-option:hover,
    .better-excalidraw-operation-option:focus-visible {
      color: var(--color-primary, #6965db);
      background: var(--button-hover-bg, #f1f0ff);
      outline: 0;
    }
    .better-excalidraw-operation-option svg {
      width: 20px;
      height: 20px;
      fill: none;
      stroke: currentColor;
      stroke-width: 1.7;
      stroke-linecap: round;
      stroke-linejoin: round;
    }
    .better-excalidraw-operation-shortcut {
      color: var(--text-secondary-color, #777780);
      font-size: 11px;
      font-weight: 500;
    }
    html.better-excalidraw-drawing .excalidraw canvas {
      cursor: crosshair !important;
    }
    #${M} {
      position: fixed;
      z-index: 19;
      pointer-events: none;
    }
    #${M} svg {
      width: 100%;
      height: 100%;
      overflow: visible;
    }
    #${M} svg > * {
      fill: rgba(105, 101, 219, .08);
      stroke: var(--color-primary, #6965db);
      stroke-width: 2;
      stroke-linejoin: round;
      vector-effect: non-scaling-stroke;
    }
    #${M} .shape-detail {
      fill: none;
    }
    #${O} {
      position: fixed;
      left: 50%;
      bottom: 24px;
      z-index: 21;
      padding: 8px 12px;
      border-radius: 9px;
      color: #fff;
      background: rgba(31, 31, 42, .88);
      box-shadow: 0 6px 20px rgba(0, 0, 0, .2);
      transform: translateX(-50%);
      pointer-events: none;
      font: 600 12px/16px system-ui, sans-serif;
    }
    #${Y} {
      position: fixed;
      left: 50%;
      bottom: 28px;
      z-index: 2147483646;
      max-width: min(420px, calc(100vw - 32px));
      padding: 10px 14px;
      border-radius: 10px;
      color: #fff;
      background: rgba(31, 31, 42, .92);
      box-shadow: 0 8px 28px rgba(0, 0, 0, .24);
      transform: translateX(-50%);
      font: 600 13px/18px system-ui, sans-serif;
    }
    @media (max-width: 700px) {
      #${B} { top: 68px; left: 8px; }
      #${h} { right: 54px; }
      #${x} { right: 8px; }
    }
    @media (prefers-reduced-motion: reduce) {
      #${y}, #${E} { animation: none; }
      .better-excalidraw-page-button { transition: none; }
    }
  `,document.head.append(e)}function ye(){const n=Array.from(document.querySelectorAll("button, [role='button']")).find(t=>{const r=`${t.getAttribute("aria-label")??""} ${t.getAttribute("title")??""}`,a=t.getBoundingClientRect();return a.width>0&&a.height>0&&/(^|\s)(矩形|Rectangle)(\s|$)/i.test(r)});if(!n)return null;let o=n.parentElement;for(let t=0;o&&t<7;t+=1,o=o.parentElement){const r=o.getBoundingClientRect();if(o.querySelectorAll("button, [role='button']").length>=8&&r.width>=320&&r.height>=36&&r.height<=80)return{referenceButton:n,toolbar:o}}return null}function Ee(e){return`${e.getAttribute("aria-label")??""} ${e.getAttribute("title")??""}`.trim()}function ve(){const e=Array.from(document.querySelectorAll(".excalidraw button, .excalidraw [role='button']")).filter(n=>{if(n.id===B||n.id===h||n.id===x)return!1;const o=n.getBoundingClientRect();return o.width>=30&&o.width<=56&&o.height>=30&&o.height<=56&&o.left>=0&&o.left<=90&&o.top>=0&&o.top<=90});return e.find(n=>/menu|菜单/i.test(Ee(n)))??e.sort((n,o)=>{const t=n.getBoundingClientRect(),r=o.getBoundingClientRect();return t.left+t.top-(r.left+r.top)})[0]??null}function U(e,n){const o=Math.round(n.width),t=Math.round(n.height);e.style.width=`${o}px`,e.style.height=`${t}px`;const r=Math.round(Math.min(22,Math.max(18,Math.min(o,t)*.55))),a=e.querySelector("svg");a&&(a.style.width=`${r}px`,a.style.height=`${r}px`)}function z(){const e=document.getElementById(B),n=document.getElementById(h),o=document.getElementById(x);if(!e||!n||!o)return;const t=ve();if(t){const a=t.getBoundingClientRect();U(e,a),e.style.left=`${Math.round(a.left)}px`,e.style.right="auto",e.style.top=`${Math.round(a.bottom+20)}px`}const r=ye();if(r){const a=r.toolbar.getBoundingClientRect(),c=r.referenceButton.getBoundingClientRect(),l=Math.round(c.width),u=6,m=l*2+u,d=a.right+10,v=d+m<=window.innerWidth-8?d:a.left-m-10,P=v+l+u;for(const[w,I]of[[n,v],[o,P]])U(w,c),w.style.left=`${Math.max(8,I)}px`,w.style.right="auto",w.style.top=`${Math.max(8,c.top)}px`}for(const[a,c]of[[y,n],[E,o]]){const l=document.getElementById(a);if(!l)continue;const u=c.getBoundingClientRect(),m=a===y?310:230,d=l.getBoundingClientRect().width||m,g=Math.min(window.innerWidth-d-8,Math.max(8,u.right-d));l.style.left=`${g}px`,l.style.top=`${u.bottom+8}px`}}function W(e){document.getElementById(Y)?.remove();const n=document.createElement("div");n.id=Y,n.setAttribute("role","status"),n.textContent=e,document.body.append(n),window.setTimeout(()=>n.remove(),2600)}function T(){document.getElementById(y)?.remove(),document.getElementById(h)?.setAttribute("aria-expanded","false")}function D(){document.getElementById(E)?.remove(),document.getElementById(x)?.setAttribute("aria-expanded","false")}function Ie(e){D(),T();const n=document.createElement("div");n.id=y,n.setAttribute("role","dialog"),n.setAttribute("aria-label","扩展图形"),n.innerHTML=`
    ${oe.map(o=>`
        <div class="better-excalidraw-shape-heading">${o.label}</div>
        <div class="better-excalidraw-shape-grid">
          ${o.shapes.map(t=>`
          <button class="better-excalidraw-shape-option" type="button" data-shape="${t.kind}" aria-label="${t.label}" title="${t.label}">
            ${re(t.icon)}
          </button>`).join("")}
        </div>`).join("")}`,n.addEventListener("click",o=>{const t=o.target.closest("[data-shape]");if(!t)return;const r=t.dataset.shape;if(!r)return;const a=be.find(c=>c.kind===r);a&&(e(a),T())}),document.body.append(n),document.getElementById(h)?.setAttribute("aria-expanded","true"),z()}function Se(e){T(),D();const n=document.createElement("div");n.id=E,n.setAttribute("role","menu"),n.setAttribute("aria-label","选中图形操作"),n.innerHTML=he.map(o=>`
      <button class="better-excalidraw-operation-option" type="button" role="menuitem" data-operation="${o.operation}">
        <svg viewBox="0 0 24 24" aria-hidden="true">${o.icon}</svg>
        <span>${o.label}</span>
        <span class="better-excalidraw-operation-shortcut">${o.shortcut??""}</span>
      </button>`).join(""),n.addEventListener("click",o=>{const r=o.target.closest("[data-operation]")?.dataset.operation;r&&(D(),e(r))}),document.body.append(n),document.getElementById(x)?.setAttribute("aria-expanded","true"),z()}function J(e,n,o){if(document.body){if(we(),!document.getElementById(B)){const t=document.createElement("button");t.id=B,t.className="better-excalidraw-page-button",t.type="button",t.title="打开本地画布工作区",t.setAttribute("aria-label","打开本地画布工作区"),t.innerHTML=fe(),t.addEventListener("click",()=>{e.onOpenWorkspace().catch(r=>{W(r instanceof Error?r.message:String(r))})}),document.body.append(t)}if(!document.getElementById(h)){const t=document.createElement("button");t.id=h,t.className="better-excalidraw-page-button",t.type="button",t.title="扩展图形",t.setAttribute("aria-label","扩展图形"),t.setAttribute("aria-expanded","false"),t.setAttribute("aria-pressed","false"),t.innerHTML=ge(),t.addEventListener("click",n),document.body.append(t)}if(!document.getElementById(x)){const t=document.createElement("button");t.id=x,t.className="better-excalidraw-page-button",t.type="button",t.title="选中图形操作",t.setAttribute("aria-label","选中图形操作"),t.setAttribute("aria-expanded","false"),t.innerHTML=xe(),t.addEventListener("click",o),document.body.append(t)}z()}}function Ae(e){let n=0,o=null,t=null;const r=()=>{document.getElementById(M)?.remove()},a=()=>{o=null,t=null,r(),document.getElementById(O)?.remove(),document.documentElement.classList.remove("better-excalidraw-drawing"),document.getElementById(h)?.setAttribute("aria-pressed","false")},c=i=>{o=i,r(),document.documentElement.classList.add("better-excalidraw-drawing"),document.getElementById(h)?.setAttribute("aria-pressed","true"),document.getElementById(O)?.remove();const s=document.createElement("div");s.id=O,s.textContent=`拖拽绘制${i.label} · Esc 取消`,document.body.append(s)},l=()=>{document.getElementById(y)?T():Ie(c)},u=i=>{e.onSelectionOperation(i).catch(s=>{W(s instanceof Error?s.message:String(s))})},m=()=>{o&&a(),document.getElementById(E)?D():Se(u)},d=()=>{window.cancelAnimationFrame(n),n=window.requestAnimationFrame(()=>J(e,l,m))};J(e,l,m);const g=new MutationObserver(d);g.observe(document.documentElement,{childList:!0,subtree:!0}),window.addEventListener("resize",d);const v=i=>{const s=i.target,p=document.getElementById(y),f=document.getElementById(h),A=document.getElementById(E),H=document.getElementById(x);p&&!p.contains(s)&&!f?.contains(s)&&T(),A&&!A.contains(s)&&!H?.contains(s)&&D(),o&&s instanceof Element&&!p?.contains(s)&&!f?.contains(s)&&s.closest(".excalidraw button, .excalidraw [role='button']")&&a()},P=i=>{i.key==="Escape"&&(o?a():(T(),D()))},w=i=>{if(!t)return null;let s=i.clientX,p=i.clientY;if(i.shiftKey){const j=Math.max(Math.abs(s-t.x),Math.abs(p-t.y));s=t.x+Math.sign(s-t.x||1)*j,p=t.y+Math.sign(p-t.y||1)*j}const f=Math.min(t.x,s),A=Math.min(t.y,p),H=Math.abs(s-t.x),q=Math.abs(p-t.y);return{centerX:f+H/2,centerY:A+q/2,height:q,left:f,top:A,width:H}},I=i=>{if(!o)return;const s=w(i);if(!s)return;let p=document.getElementById(M);p||(p=document.createElement("div"),p.id=M,p.innerHTML=re(o.icon),document.body.append(p)),p.style.left=`${s.left}px`,p.style.top=`${s.top}px`,p.style.width=`${Math.max(1,s.width)}px`,p.style.height=`${Math.max(1,s.height)}px`},R=i=>{!o||i.button!==0||!(i.target instanceof HTMLCanvasElement)||(i.preventDefault(),i.stopImmediatePropagation(),t={x:i.clientX,y:i.clientY,pointerId:i.pointerId},I(i))},_=i=>{!t||i.pointerId!==t.pointerId||(i.preventDefault(),i.stopImmediatePropagation(),I(i))},S=i=>{if(!t||!o||i.pointerId!==t.pointerId)return;i.preventDefault(),i.stopImmediatePropagation();const s=w(i),p=o;a(),!(!s||s.width<4||s.height<4)&&e.onDrawShape(p.kind,s).catch(f=>{W(f instanceof Error?f.message:String(f))})},C=i=>{!t||i.pointerId!==t.pointerId||(i.preventDefault(),i.stopImmediatePropagation(),a())};return document.addEventListener("click",v,!0),document.addEventListener("keydown",P,!0),document.addEventListener("pointerdown",R,!0),document.addEventListener("pointermove",_,!0),document.addEventListener("pointerup",S,!0),document.addEventListener("pointercancel",C,!0),()=>{g.disconnect(),window.cancelAnimationFrame(n),window.removeEventListener("resize",d),document.removeEventListener("click",v,!0),document.removeEventListener("keydown",P,!0),document.removeEventListener("pointerdown",R,!0),document.removeEventListener("pointermove",_,!0),document.removeEventListener("pointerup",S,!0),document.removeEventListener("pointercancel",C,!0),a(),document.getElementById(B)?.remove(),document.getElementById(h)?.remove(),document.getElementById(y)?.remove(),document.getElementById(x)?.remove(),document.getElementById(E)?.remove()}}const Z=".excalidraw",ke="files-db",Me=["files-store","files","binaryFiles"],L="better-excalidraw-save-overlay",G="better-excalidraw-save-style",ae="application/vnd.excalidraw.clipboard+json";function Q(e){return e instanceof Error?e.message:String(e)}function $(e,n){if(!e)return n;try{return JSON.parse(e)}catch{return n}}function Be(e){return!e||typeof e!="object"?!1:Array.isArray(e.elements)}async function Pe(e,n){const o=JSON.parse(n);if(!Be(o))throw new Error("文件不是有效的 Excalidraw 画布");const t=document.querySelector(Z);if(!t)throw new Error("没有找到 Excalidraw 画布，请刷新网页后重试");const r=new File([n],e,{type:"application/json",lastModified:Date.now()}),a=new DataTransfer;a.items.add(r);for(const c of["dragenter","dragover","drop"])t.dispatchEvent(new DragEvent(c,{bubbles:!0,cancelable:!0,dataTransfer:a}));return await new Promise(c=>window.setTimeout(c,350)),ie()}function Ce(){return new Promise(e=>{const n=indexedDB.open(ke);n.onerror=()=>e(null),n.onblocked=()=>e(null),n.onupgradeneeded=()=>{n.transaction?.abort(),e(null)},n.onsuccess=()=>e(n.result)})}async function Te(e){if(e.size===0)return{};const n=await Ce();if(!n)return{};const o=Me.find(t=>n.objectStoreNames.contains(t));if(!o)return n.close(),{};try{return await new Promise((t,r)=>{const a={},c=n.transaction(o,"readonly"),l=c.objectStore(o).openCursor();l.onerror=()=>r(l.error),l.onsuccess=()=>{const u=l.result;if(!u)return;const m=String(u.key);e.has(m)&&(a[m]=u.value),u.continue()},c.oncomplete=()=>t(a),c.onerror=()=>r(c.error),c.onabort=()=>r(c.error)})}finally{n.close()}}function De(e){const n=new Set;for(const o of e){if(!o||typeof o!="object")continue;const t=o.fileId;typeof t=="string"&&t&&n.add(t)}return n}function _e(e,n="正在保存当前画布…"){if(document.getElementById(L)?.remove(),!e)return;if(!document.getElementById(G)){const a=document.createElement("style");a.id=G,a.textContent=`
      @keyframes better-excalidraw-spin {
        to { transform: rotate(360deg); }
      }
      #${L} {
        position: fixed;
        inset: 0;
        z-index: 2147483647;
        display: grid;
        place-items: center;
        background: rgba(20, 20, 28, 0.24);
        backdrop-filter: blur(2px);
        pointer-events: all;
      }
      #${L} > div {
        display: flex;
        align-items: center;
        gap: 12px;
        min-width: 210px;
        padding: 15px 18px;
        border: 1px solid rgba(255, 255, 255, 0.34);
        border-radius: 14px;
        color: #fff;
        background: rgba(31, 31, 42, 0.9);
        box-shadow: 0 14px 42px rgba(0, 0, 0, 0.28);
        font: 600 14px/20px Inter, system-ui, sans-serif;
      }
      #${L} span {
        width: 22px;
        height: 22px;
        flex: 0 0 auto;
        border: 3px solid rgba(255, 255, 255, 0.28);
        border-top-color: #a8a5ff;
        border-radius: 50%;
        animation: better-excalidraw-spin 0.75s linear infinite;
      }
    `,document.head.append(a)}const o=document.createElement("div");o.id=L,o.setAttribute("role","status"),o.setAttribute("aria-live","polite");const t=document.createElement("div"),r=document.createElement("span");r.setAttribute("aria-hidden","true"),t.append(r,document.createTextNode(n)),o.append(t),document.body.append(o)}async function ie(){const e=$(localStorage.getItem("excalidraw"),[]),n=$(localStorage.getItem("excalidraw-state"),{}),o=await Te(De(e));return JSON.stringify({type:"excalidraw",version:2,source:"https://excalidraw.com",elements:e,appState:n,files:o},null,2)}function ce(e){const n=e.zoom;if(typeof n=="number"&&n>0)return n;if(n&&typeof n=="object"){const o=n.value;if(typeof o=="number"&&o>0)return o}return 1}async function Le(e,n){const o=document.querySelector(Z),t=document.elementFromPoint(n.centerX,n.centerY),r=t instanceof HTMLCanvasElement?t:o?.querySelector("canvas");if(!o||!r)throw new Error("没有找到 Excalidraw 画布");const a=$(localStorage.getItem("excalidraw-state"),{}),c=ce(a),l=me(e,a,n.width/c,n.height/c),u=JSON.stringify({type:"excalidraw/clipboard",elements:l,files:{}});o.hasAttribute("tabindex")||o.setAttribute("tabindex","-1"),o.focus({preventScroll:!0});const m={bubbles:!0,cancelable:!0,clientX:n.centerX,clientY:n.centerY,pointerId:1,pointerType:"mouse"};r.dispatchEvent(new PointerEvent("pointermove",m)),r.dispatchEvent(new MouseEvent("mousemove",{bubbles:!0,cancelable:!0,clientX:n.centerX,clientY:n.centerY}));const d=new DataTransfer;d.setData("application/vnd.excalidraw.clipboard+json",u),d.setData("text/plain",u),document.dispatchEvent(new ClipboardEvent("paste",{bubbles:!0,cancelable:!0,clipboardData:d})),await new Promise(g=>window.setTimeout(g,80))}function V(){const e=document.querySelector(Z);if(!e)throw new Error("没有找到 Excalidraw 画布");return e.hasAttribute("tabindex")||e.setAttribute("tabindex","-1"),e.focus({preventScroll:!0}),e}async function se(){const e=V(),n=new DataTransfer;e.dispatchEvent(new ClipboardEvent("copy",{bubbles:!0,cancelable:!0,clipboardData:n})),await Promise.resolve();const o=n.getData(ae)||n.getData("text/plain");if(!o)throw new Error("请先在画布中选中一个或多个图形");const t=JSON.parse(o),r=(t.elements??[]).filter(d=>!d.isDeleted);if(r.length===0)throw new Error("请先在画布中选中一个或多个图形");const c=$(localStorage.getItem("excalidraw-state"),{}).selectedElementIds??{},l=r.filter(d=>c[d.id]);if(l.length>0)return{allElements:r,files:t.files??{},selectedElements:l};const u=new Set(r.map(d=>d.id)),m=r.filter(d=>!d.containerId||!u.has(d.containerId));return{allElements:r,files:t.files??{},selectedElements:m.length>0?m:r}}async function X(){return(await se()).selectedElements}function N({code:e,key:n,primary:o=!1,shiftKey:t=!1}){const r=V(),a=/Mac|iPhone|iPad|iPod/i.test(navigator.platform),c={bubbles:!0,cancelable:!0,code:e,key:n,ctrlKey:o&&!a,metaKey:o&&a,shiftKey:t};r.dispatchEvent(new KeyboardEvent("keydown",c)),r.dispatchEvent(new KeyboardEvent("keyup",c))}function le(e,n,o,t,r){const a=Math.cos(r),c=Math.sin(r),l=e-o,u=n-t;return{x:o+l*a-u*c,y:t+l*c+u*a}}function $e(e){const n=e.x+e.width/2,o=e.y+e.height/2,t=e.angle??0,a=[[e.x,e.y],[e.x+e.width,e.y],[e.x+e.width,e.y+e.height],[e.x,e.y+e.height]].map(([c,l])=>le(c,l,n,o,t));return{minX:Math.min(...a.map(c=>c.x)),minY:Math.min(...a.map(c=>c.y)),maxX:Math.max(...a.map(c=>c.x)),maxY:Math.max(...a.map(c=>c.y))}}function Re(e,n,o,t){const r=ce(o),a=typeof o.scrollX=="number"?o.scrollX:0,c=typeof o.scrollY=="number"?o.scrollY:0,l=t.getBoundingClientRect();return{x:l.left+(e+a)*r,y:l.top+(n+c)*r}}async function ee(e){const n=await se(),{allElements:o,files:t,selectedElements:r}=n;if(!r[0])throw new Error("请先在画布中选中一个或多个图形");if(r.some(i=>i.locked||i.elbowed||i.type==="frame"||i.type==="magicframe"))throw new Error("当前选区包含不能旋转的图形");const a=V(),c=a.querySelector("canvas.excalidraw__canvas.interactive")??a.querySelector("canvas");if(!c)throw new Error("没有找到 Excalidraw 交互画布");const l=$(localStorage.getItem("excalidraw-state"),{}),u=e?Math.PI/2:-Math.PI/2,m=r.map($e),d=Math.min(...m.map(i=>i.minX)),g=Math.min(...m.map(i=>i.minY)),v=Math.max(...m.map(i=>i.maxX)),P=Math.max(...m.map(i=>i.maxY)),w=(d+v)/2,I=(g+P)/2,R=o.map(i=>{const s=i.x+i.width/2,p=i.y+i.height/2,f=le(s,p,w,I,u),A=((i.angle??0)+u+Math.PI*2)%(Math.PI*2);return{...i,x:i.x+f.x-s,y:i.y+f.y-p,angle:A}}),_=JSON.stringify({type:"excalidraw/clipboard",elements:R,files:t});N({code:"Delete",key:"Delete"}),await new Promise(i=>window.requestAnimationFrame(()=>i()));const S=Re(w,I,l,c);c.dispatchEvent(new PointerEvent("pointermove",{bubbles:!0,cancelable:!0,clientX:S.x,clientY:S.y,pointerId:1,pointerType:"mouse"})),c.dispatchEvent(new MouseEvent("mousemove",{bubbles:!0,cancelable:!0,clientX:S.x,clientY:S.y}));const C=new DataTransfer;C.setData(ae,_),C.setData("text/plain",_),document.dispatchEvent(new ClipboardEvent("paste",{bubbles:!0,cancelable:!0,clipboardData:C})),await new Promise(i=>window.setTimeout(i,80))}async function He(e){switch(e){case"duplicate":await X(),N({code:"KeyD",key:"d",primary:!0});return;case"flipHorizontal":await X(),N({code:"KeyH",key:"H",shiftKey:!0});return;case"flipVertical":await X(),N({code:"KeyV",key:"V",shiftKey:!0});return;case"rotateClockwise":await ee(!0);return;case"rotateCounterclockwise":await ee(!1)}}async function Oe(){const e=await chrome.runtime.sendMessage({type:"BETTER_EXCALIDRAW_OPEN_SIDE_PANEL"});if(!e.ok)throw new Error(e.error)}chrome.runtime.onMessage.addListener((e,n,o)=>e.type==="BETTER_EXCALIDRAW_PING"?(o({ok:!0}),!1):e.type==="BETTER_EXCALIDRAW_LOAD_CANVAS"?(Pe(e.fileName,e.content).then(t=>o({ok:!0,content:t})).catch(t=>o({ok:!1,error:Q(t)})),!0):e.type==="BETTER_EXCALIDRAW_CAPTURE_CANVAS"?(ie().then(t=>o({ok:!0,content:t})).catch(t=>o({ok:!1,error:Q(t)})),!0):(e.type==="BETTER_EXCALIDRAW_SET_SAVE_STATUS"&&(_e(e.visible,e.text),o({ok:!0})),!1));Ae({onDrawShape:Le,onOpenWorkspace:Oe,onSelectionOperation:He});
//# sourceMappingURL=content.ts-T7As_3Le.js.map
})()
