import{t as r,a as _,c as R,l as P}from"./i18n-Dzxum2lC.js";(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))o(s);new MutationObserver(s=>{for(const c of s)if(c.type==="childList")for(const p of c.addedNodes)p.tagName==="LINK"&&p.rel==="modulepreload"&&o(p)}).observe(document,{childList:!0,subtree:!0});function n(s){const c={};return s.integrity&&(c.integrity=s.integrity),s.referrerPolicy&&(c.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?c.credentials="include":s.crossOrigin==="anonymous"?c.credentials="omit":c.credentials="same-origin",c}function o(s){if(s.ep)return;s.ep=!0;const c=n(s);fetch(s.href,c)}})();const W="better-excalidraw-workspace",M=1,w="settings",N="workspace-directory-handle";function T(){return new Promise((e,t)=>{const n=indexedDB.open(W,M);n.onerror=()=>t(n.error),n.onupgradeneeded=()=>{n.result.objectStoreNames.contains(w)||n.result.createObjectStore(w)},n.onsuccess=()=>e(n.result)})}async function B(e){const t=await T();try{await new Promise((n,o)=>{const s=t.transaction(w,"readwrite");s.objectStore(w).put(e,N),s.oncomplete=()=>n(),s.onerror=()=>o(s.error),s.onabort=()=>o(s.error)})}finally{t.close()}}async function I(){const e=await T();try{return await new Promise((t,n)=>{const s=e.transaction(w,"readonly").objectStore(w).get(N);s.onsuccess=()=>t(s.result??null),s.onerror=()=>n(s.error)})}finally{e.close()}}const k=30,x=5,D=3600,S="autosaveSeconds",a={directory:null,canvases:[],activePath:null,filter:"",busy:!1,status:r("initialStatus"),permissionRequired:!1,autosaveSeconds:k,createDialogOpen:!1,newCanvasName:"",newCanvasError:""};let g=null,C=null,$=!1;function H(){const e=document.querySelector("#app");if(!e)throw new Error("Missing app root");return e}const u=H();_();document.title=chrome.i18n.getMessage("extensionName")||"Better Excalidraw Workspace";function f(e){return e instanceof Error?e.message:String(e)}function l(e){const t=document.createElement("span");return t.textContent=e,t.innerHTML}function U(e){return e<1024?`${e} B`:e<1024*1024?`${(e/1024).toFixed(1)} KB`:`${(e/1024/1024).toFixed(1)} MB`}function V(e){return new Intl.DateTimeFormat(P,{month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit"}).format(e)}function m(e){return`<svg viewBox="0 0 20 20" aria-hidden="true">${{folder:'<path d="M3.5 6.25A1.75 1.75 0 0 1 5.25 4.5h3.02l1.5 1.75h5.98A1.75 1.75 0 0 1 17.5 8v6.75a1.75 1.75 0 0 1-1.75 1.75H5.25a1.75 1.75 0 0 1-1.75-1.75v-8.5Z"/>',refresh:'<path d="M16.5 6.5v-3m0 0h-3m3 0-2.15 2.15a6.5 6.5 0 1 0 1.38 7.1"/>',save:'<path d="M4 3.5h9.8L17 6.7v9.8H4v-13Z"/><path d="M7 3.5v5h7v-5M7 16.5v-5h7v5"/>',search:'<circle cx="9" cy="9" r="5.5"/><path d="m13 13 4 4"/>',canvas:'<rect x="3.5" y="3.5" width="13" height="13" rx="2"/><path d="m6.5 12 2.6-2.7 2.1 2 1.6-1.5 2.2 2.2"/>'}[e]}</svg>`}function d(){const e=a.filter.trim().toLocaleLowerCase(),t=a.canvases.filter(o=>o.relativePath.toLocaleLowerCase().includes(e)),n=a.directory?.name??r("workspaceNotSelected");u.innerHTML=`
    <main class="shell">
      <header class="header">
        <div class="brand-mark">B</div>
        <div class="brand-copy">
          <h1>Better Excalidraw</h1>
          <p>${r("localCanvasWorkspace")}</p>
        </div>
      </header>

      <section class="workspace-card">
        <div class="workspace-heading">
          <div class="workspace-icon">${m("folder")}</div>
          <div class="workspace-copy">
            <strong title="${l(n)}">${l(n)}</strong>
            <span>${R(a.canvases.length)}</span>
          </div>
        </div>
        <button class="primary-button" data-action="choose-workspace" ${a.busy?"disabled":""}>
          ${a.directory?r("changeFolder"):r("openWorkspaceFolder")}
        </button>
        <button class="secondary-button" data-action="new-canvas" ${!a.directory||a.busy?"disabled":""}>
          ${r("newCanvas")}
        </button>
        ${a.permissionRequired?`<button class="secondary-button" data-action="reconnect">${r("reauthorizeFolder")}</button>`:""}
      </section>

      <section class="toolbar" aria-label="${r("canvasToolbar")}">
        <label class="search-field">
          ${m("search")}
          <input type="search" placeholder="${r("searchCanvas")}" value="${l(a.filter)}" data-role="search" />
        </label>
        <button class="icon-button" title="${r("rescan")}" aria-label="${r("rescan")}" data-action="refresh" ${!a.directory||a.busy?"disabled":""}>
          ${m("refresh")}
        </button>
        <button class="icon-button" title="${r("saveCurrentCanvas")}" aria-label="${r("saveCurrentCanvas")}" data-action="save" ${!a.activePath||a.busy?"disabled":""}>
          ${m("save")}
        </button>
      </section>

      <section class="autosave-settings" aria-label="${r("autosaveSettings")}">
        <label for="autosave-seconds">${r("autosave")}</label>
        <input
          id="autosave-seconds"
          data-role="autosave-seconds"
          type="number"
          min="0"
          max="${D}"
          step="5"
          value="${a.autosaveSeconds}"
          aria-describedby="autosave-hint"
        />
        <span>${r("seconds")}</span>
        <small id="autosave-hint">${r("autosaveHint",{min:x})}</small>
      </section>

      <section class="canvas-list" aria-label="${r("workspaceCanvases")}">
        ${t.length?t.map(o=>`
                    <button class="canvas-row ${a.activePath===o.relativePath?"active":""}" data-canvas-path="${l(o.relativePath)}" ${a.busy?"disabled":""}>
                      <span class="canvas-icon">${m("canvas")}</span>
                      <span class="canvas-copy">
                        <strong>${l(o.name.replace(/\.excalidraw$/i,""))}</strong>
                        <small>${l(o.relativePath)} · ${U(o.size)} · ${V(o.modifiedAt)}</small>
                      </span>
                    </button>
                  `).join(""):`<div class="empty-state">${a.directory?e?r("noMatchingCanvases"):r("noCanvasFiles"):r("openFolderEmpty")}</div>`}
      </section>

      <footer class="status ${a.busy?"busy":""}">
        <span class="status-dot"></span>
        <span>${l(a.status)}</span>
      </footer>
      ${a.createDialogOpen?`<div class="dialog-backdrop" data-role="dialog-backdrop">
              <form class="create-dialog" data-role="new-canvas-form">
                <h2>${r("newCanvas")}</h2>
                <p>${r("newCanvasDescription")}</p>
                <label>
                  <span>${r("canvasName")}</span>
                  <input data-role="new-canvas-name" value="${l(a.newCanvasName)}" autocomplete="off" autofocus />
                </label>
                ${a.newCanvasError?`<p class="dialog-error" role="alert">${l(a.newCanvasError)}</p>`:""}
                <div class="dialog-actions">
                  <button type="button" class="dialog-button" data-action="cancel-new-canvas">${r("cancel")}</button>
                  <button type="submit" class="dialog-button primary">${r("create")}</button>
                </div>
              </form>
            </div>`:""}
    </main>
  `}function i(e,t=!1){a.status=e,a.busy=t,d()}async function L(){try{await navigator.storage?.persist?.()}catch{}}async function y(e,t){const n={mode:"readwrite"};return await e.queryPermission(n)==="granted"?!0:t?await e.requestPermission(n)==="granted":!1}async function O(e,t=""){const n=[];for await(const[o,s]of e.entries()){if(o.startsWith("."))continue;const c=t?`${t}/${o}`:o;if(s.kind==="directory"){n.push(...await O(s,c));continue}if(!o.toLocaleLowerCase().endsWith(".excalidraw"))continue;const p=await s.getFile();n.push({name:o,relativePath:c,handle:s,size:p.size,modifiedAt:p.lastModified})}return n.sort((o,s)=>o.relativePath.localeCompare(s.relativePath,P))}async function h(){if(a.directory){i(r("scanningWorkspace"),!0);try{if(!await y(a.directory,!1)){a.permissionRequired=!0,a.canvases=[],i(r("permissionRequired"));return}a.permissionRequired=!1,a.canvases=await O(a.directory),a.activePath&&!a.canvases.some(e=>e.relativePath===a.activePath)&&(a.activePath=null),i(r("canvasesRead",{count:a.canvases.length}))}catch(e){i(r("scanFailed",{error:f(e)}))}}}async function z(){try{const e=await window.showDirectoryPicker({id:"better-excalidraw-workspace",mode:"readwrite",startIn:a.directory??"documents"});a.directory=e,a.activePath=null,a.permissionRequired=!1,await B(e),await L(),await h()}catch(e){if(e instanceof DOMException&&e.name==="AbortError")return;i(r("openFolderFailed",{error:f(e)}))}}function K(){const e=new Set(a.canvases.map(n=>n.name.replace(/\.excalidraw$/i,"")));let t=1;for(;e.has(t===1?r("unnamedCanvas"):r("unnamedCanvasNumbered",{index:t}));)t+=1;return t===1?r("unnamedCanvas"):r("unnamedCanvasNumbered",{index:t})}function X(){a.newCanvasName=K(),a.newCanvasError="",a.createDialogOpen=!0,d(),window.requestAnimationFrame(()=>{const e=u.querySelector("[data-role='new-canvas-name']");e?.focus(),e?.select()})}function A(){a.createDialogOpen=!1,a.newCanvasName="",a.newCanvasError="",d()}function v(e){a.newCanvasError=e,d(),window.requestAnimationFrame(()=>{u.querySelector("[data-role='new-canvas-name']")?.focus()})}async function j(){if(!a.directory)return;const e=a.newCanvasName.trim();if(!e){v(r("enterCanvasName"));return}if(/[\\/:*?\"<>|\0]/.test(e)){v(r("invalidCanvasNameChars"));return}if(e.startsWith(".")){v(r("invalidCanvasNameDot"));return}const t=e.toLocaleLowerCase().endsWith(".excalidraw")?e:`${e}.excalidraw`;try{if(!await y(a.directory,!0)){v(r("noWritePermission"));return}try{await a.directory.getFileHandle(t),v(r("duplicateCanvasName"));return}catch(s){if(!(s instanceof DOMException&&s.name==="NotFoundError"))throw s}if(a.createDialogOpen=!1,a.newCanvasError="",d(),a.activePath&&!await E({quiet:!0,refresh:!1,displayLoading:!0,loadingText:r("savingCurrent")})){a.createDialogOpen=!0,a.newCanvasName=e,v(r("createSaveFailed"));return}i(r("creatingCanvas",{name:t}),!0);const o=await(await a.directory.getFileHandle(t,{create:!0})).createWritable();try{await o.write(JSON.stringify({type:"excalidraw",version:2,source:"https://excalidraw.com",elements:[],appState:{viewBackgroundColor:"#ffffff"},files:{}},null,2)),await o.close()}catch(s){throw await o.abort().catch(()=>{}),s}a.activePath=null,C=null,await h(),await q(t)}catch(n){const o=r("createFailed",{error:f(n)});a.createDialogOpen?v(o):i(o)}}async function G(){const t=(await chrome.tabs.query({active:!0,currentWindow:!0}))[0];if(!t?.id||!t.url?.startsWith("https://excalidraw.com/"))throw new Error(r("selectExcalidrawTab"));return t}async function b(e){const t=await G();return chrome.tabs.sendMessage(t.id,e)}async function q(e){const t=a.canvases.find(n=>n.relativePath===e);if(t&&t.relativePath!==a.activePath&&!(a.activePath&&!await E({quiet:!0,refresh:!1,displayLoading:!0,loadingText:r("savingAndSwitching")}))){i(r("loadingCanvas",{name:t.name}),!0);try{const o=await(await t.handle.getFile()).text(),s=await b({type:"BETTER_EXCALIDRAW_LOAD_CANVAS",fileName:t.name,content:o});if(!s.ok)throw new Error(s.error);a.activePath=t.relativePath,C=s.content??o,i(r("openedCanvas",{name:t.name}))}catch(n){i(r("loadFailed",{error:f(n)}))}}}async function E(e={}){const t=a.canvases.find(n=>n.relativePath===a.activePath);if(!t||!a.directory)return!0;if(a.busy||$)return!1;$=!0,e.quiet||i(r("savingCanvas",{name:t.name}),!0);try{if(e.displayLoading){const s=await b({type:"BETTER_EXCALIDRAW_SET_SAVE_STATUS",visible:!0,text:e.loadingText});if(!s.ok)throw new Error(s.error)}if(!await y(a.directory,!0))throw new Error(r("noWritePermission"));const n=await b({type:"BETTER_EXCALIDRAW_CAPTURE_CANVAS"});if(!n.ok)throw new Error(n.error);if(!n.content)throw new Error(r("missingCanvasContent"));if(n.content===C)return e.quiet||i(r("noUnsavedChanges",{name:t.name})),!0;const o=await t.handle.createWritable();return await o.write(n.content),await o.close(),C=n.content,e.refresh!==!1&&await h(),i(r(e.quiet?"autosavedCanvas":"savedCanvas",{name:t.name})),!0}catch(n){return i(r("saveFailed",{error:f(n)})),!1}finally{if(e.displayLoading)try{await b({type:"BETTER_EXCALIDRAW_SET_SAVE_STATUS",visible:!1})}catch{}$=!1}}function F(){g!==null&&(window.clearInterval(g),g=null),a.autosaveSeconds!==0&&(g=window.setInterval(()=>{!a.activePath||a.busy||E({quiet:!0,refresh:!1})},a.autosaveSeconds*1e3))}async function Y(e){const t=Number.parseInt(e,10),n=Number.isFinite(t)?t===0?0:Math.min(D,Math.max(x,t)):k;a.autosaveSeconds=n,await chrome.storage.local.set({[S]:n}),F(),i(n===0?r("autosaveDisabled"):r("autosaveInterval",{seconds:n}))}async function Z(){const t=(await chrome.storage.local.get(S))[S];typeof t=="number"&&t>=0&&(a.autosaveSeconds=t),F()}async function J(){if(a.directory)try{if(!await y(a.directory,!0)){i(r("authorizationNotGranted"));return}a.permissionRequired=!1,await h()}catch(e){i(r("authorizationFailed",{error:f(e)}))}}u.addEventListener("click",e=>{const t=e.target;if(t.dataset.role==="dialog-backdrop"){A();return}const n=t.closest("[data-action]"),o=t.closest("[data-canvas-path]");if(o?.dataset.canvasPath){q(o.dataset.canvasPath);return}switch(n?.dataset.action){case"choose-workspace":z();break;case"reconnect":J();break;case"new-canvas":X();break;case"cancel-new-canvas":A();break;case"refresh":h();break;case"save":E({displayLoading:!0,loadingText:r("savingCurrent")});break}});u.addEventListener("input",e=>{const t=e.target;if(t.dataset.role==="new-canvas-name"){a.newCanvasName=t.value;return}if(t.dataset.role!=="search")return;a.filter=t.value,d();const n=u.querySelector("[data-role='search']");n?.focus(),n?.setSelectionRange(a.filter.length,a.filter.length)});u.addEventListener("submit",e=>{e.target.dataset.role==="new-canvas-form"&&(e.preventDefault(),j())});u.addEventListener("change",e=>{const t=e.target;t.dataset.role==="autosave-seconds"&&Y(t.value)});async function Q(){d();try{await Z(),d();const e=await I();if(!e)return;if(a.directory=e,await L(),!await y(e,!1)){a.permissionRequired=!0,i(r("securityReauthorize"));return}await h()}catch(e){i(r("restoreFailed",{error:f(e)}))}}Q();
//# sourceMappingURL=sidepanel.html-BDYOtu0a.js.map
