import{t as s}from"./i18n-Dzxum2lC.js";const v=180,b=(e,n=!1)=>({type:"line",points:[...e,e[0]],closed:!0,round:n}),B=(e,n=!1)=>({type:"line",points:e,round:n}),ue={triangle:[b([[90,0],[180,180],[0,180]])],rightTriangle:[b([[0,0],[180,180],[0,180]])],pentagon:[b([[90,0],[180,69],[146,180],[34,180],[0,69]])],hexagon:[b([[45,0],[135,0],[180,90],[135,180],[45,180],[0,90]])],trapezoid:[b([[45,0],[135,0],[180,180],[0,180]])],parallelogram:[b([[45,0],[180,0],[135,180],[0,180]])],star:[b([[90,0],[111,62],[176,62],[123,101],[144,164],[90,126],[36,164],[57,101],[4,62],[69,62]])],chevron:[b([[0,0],[110,0],[180,90],[110,180],[0,180],[70,90]])],speechBubble:[b([[25,15],[155,15],[175,35],[175,115],[155,135],[105,135],[80,170],[68,135],[25,135],[5,115],[5,35]],!0)],plus:[b([[60,0],[120,0],[120,60],[180,60],[180,120],[120,120],[120,180],[60,180],[60,120],[0,120],[0,60],[60,60]])],pie:[{type:"ellipse",x:0,y:0,width:180,height:180},B([[90,90],[90,0]]),B([[90,90],[180,90]])],cube:[b([[0,45],[125,45],[125,180],[0,180]]),b([[0,45],[55,0],[180,0],[125,45]]),b([[125,45],[180,0],[180,135],[125,180]])],leftArrow:[b([[0,90],[70,20],[70,60],[180,60],[180,120],[70,120],[70,160]])],rightArrow:[b([[180,90],[110,20],[110,60],[0,60],[0,120],[110,120],[110,160]])],doubleArrow:[b([[0,90],[55,25],[55,60],[125,60],[125,25],[180,90],[125,155],[125,120],[55,120],[55,155]])],decision:[b([[90,0],[180,90],[90,180],[0,90]])],process:[b([[0,0],[180,0],[180,180],[0,180]]),B([[35,0],[35,180]]),B([[145,0],[145,180]])],internalStorage:[b([[0,0],[180,0],[180,180],[0,180]]),B([[35,0],[35,180]]),B([[0,35],[180,35]])],offPageConnector:[b([[0,0],[180,0],[180,120],[90,180],[0,120]])],card:[b([[0,0],[135,0],[180,45],[180,180],[0,180]]),B([[135,0],[135,45],[180,45]])]};function oe(){return crypto.randomUUID().replaceAll("-","").slice(0,20)}function U(){return Math.floor(Math.random()*2e9)+1}function re(e,n){return{id:oe(),angle:0,strokeColor:e.currentItemStrokeColor??"#1e1e1e",fillStyle:e.currentItemFillStyle??"solid",strokeWidth:e.currentItemStrokeWidth??2,strokeStyle:e.currentItemStrokeStyle??"solid",roughness:e.currentItemRoughness??1,opacity:e.currentItemOpacity??100,groupIds:n,frameId:null,seed:U(),version:1,versionNonce:U(),isDeleted:!1,boundElements:[],updated:Date.now(),created:Date.now(),link:null,locked:!1}}function me(e,n,o,t,r){const a=Math.min(...e.points.map(([p])=>p)),c=Math.min(...e.points.map(([,p])=>p)),d=Math.max(...e.points.map(([p])=>p)),u=Math.max(...e.points.map(([,p])=>p)),h=e.points.map(([p,x])=>[(p-a)/v*o,(x-c)/v*t]);return{...re(n,r),type:"line",x:a/v*o,y:c/v*t,width:(d-a)/v*o,height:(u-c)/v*t,backgroundColor:e.closed?n.currentItemBackgroundColor??"transparent":"transparent",roundness:e.round?{type:2}:null,points:h,lastCommittedPoint:null,startBinding:null,endBinding:null,startArrowhead:null,endArrowhead:null,elbowed:!1,polygon:e.closed===!0}}function he(e,n,o,t,r){return{...re(n,r),type:"ellipse",x:e.x/v*o,y:e.y/v*t,width:e.width/v*o,height:e.height/v*t,backgroundColor:n.currentItemBackgroundColor??"transparent",roundness:null}}function be(e,n,o,t){const r=Math.max(1,o),a=Math.max(1,t),c=ue[e],d=c.length>1?[oe()]:[];return c.map(u=>u.type==="ellipse"?he(u,n,r,a,d):me(u,n,r,a,d))}const J="better-excalidraw-page-ui-styles",T="better-excalidraw-workspace-button",f="better-excalidraw-shapes-button",E="better-excalidraw-shapes-panel",w="better-excalidraw-operations-button",I="better-excalidraw-operations-panel",z="better-excalidraw-page-toast",C="better-excalidraw-draw-preview",H="better-excalidraw-draw-hint",ae=[{label:s("categoryBasic"),shapes:[{kind:"triangle",label:s("triangle"),icon:'<polygon points="12,3 21,21 3,21"/>'},{kind:"rightTriangle",label:s("rightTriangle"),icon:'<polygon points="4,3 21,21 4,21"/>'},{kind:"pentagon",label:s("pentagon"),icon:'<polygon points="12,2 22,9 18,21 6,21 2,9"/>'},{kind:"hexagon",label:s("hexagon"),icon:'<polygon points="6,3 18,3 23,12 18,21 6,21 1,12"/>'},{kind:"trapezoid",label:s("trapezoid"),icon:'<polygon points="7,3 17,3 22,21 2,21"/>'},{kind:"parallelogram",label:s("parallelogram"),icon:'<polygon points="7,3 22,3 17,21 2,21"/>'},{kind:"star",label:s("star"),icon:'<polygon points="12,2 14.5,9 22,9 16,13.5 18.5,21 12,16.5 5.5,21 8,13.5 2,9 9.5,9"/>'},{kind:"chevron",label:s("chevron"),icon:'<polygon points="3,3 14,3 22,12 14,21 3,21 11,12"/>'},{kind:"speechBubble",label:s("speechBubble"),icon:'<path d="M4 4h16v12H12l-4 4v-4H4Z"/>'},{kind:"plus",label:s("plus"),icon:'<polygon points="9,2 15,2 15,9 22,9 22,15 15,15 15,22 9,22 9,15 2,15 2,9 9,9"/>'},{kind:"pie",label:s("pie"),icon:'<circle cx="12" cy="12" r="9"/><path class="shape-detail" d="M12 12V3m0 9h9"/>'},{kind:"cube",label:s("cube"),icon:'<path d="m4 7 8-4 8 4v10l-8 4-8-4Z"/><path class="shape-detail" d="m4 7 8 4 8-4M12 11v10"/>'}]},{label:s("categoryArrows"),shapes:[{kind:"leftArrow",label:s("leftArrow"),icon:'<polygon points="2,12 10,4 10,9 22,9 22,15 10,15 10,20"/>'},{kind:"rightArrow",label:s("rightArrow"),icon:'<polygon points="22,12 14,4 14,9 2,9 2,15 14,15 14,20"/>'},{kind:"doubleArrow",label:s("doubleArrow"),icon:'<polygon points="2,12 8,5 8,9 16,9 16,5 22,12 16,19 16,15 8,15 8,19"/>'}]},{label:s("categoryFlowchart"),shapes:[{kind:"decision",label:s("decision"),icon:'<polygon points="12,2 22,12 12,22 2,12"/>'},{kind:"process",label:s("predefinedProcess"),icon:'<rect x="3" y="3" width="18" height="18"/><path class="shape-detail" d="M7 3v18M17 3v18"/>'},{kind:"internalStorage",label:s("internalStorage"),icon:'<rect x="3" y="3" width="18" height="18"/><path class="shape-detail" d="M7 3v18M3 7h18"/>'},{kind:"offPageConnector",label:s("offPageConnector"),icon:'<polygon points="3,3 21,3 21,15 12,21 3,15"/>'},{kind:"card",label:s("card"),icon:'<path d="M3 3h13l5 5v13H3Z"/><path class="shape-detail" d="M16 3v5h5"/>'}]}],fe=ae.flatMap(e=>e.shapes),ge=[{operation:"duplicate",label:s("duplicate"),shortcut:"Ctrl/⌘ D",icon:'<rect x="7" y="7" width="11" height="11" rx="2"/><path d="M15 7V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>'},{operation:"rotateClockwise",label:s("rotateClockwise"),icon:'<path d="M19 8V3m0 0h-5m5 0-3.2 3.2A8 8 0 1 0 20 13"/>'},{operation:"rotateCounterclockwise",label:s("rotateCounterclockwise"),icon:'<path d="M5 8V3m0 0h5M5 3l3.2 3.2A8 8 0 1 1 4 13"/>'},{operation:"flipHorizontal",label:s("flipHorizontal"),shortcut:"Shift H",icon:'<path d="M12 3v18M9 5 3 9v6l6 4V5Zm6 0 6 4v6l-6 4V5Z"/>'},{operation:"flipVertical",label:s("flipVertical"),shortcut:"Shift V",icon:'<path d="M3 12h18M5 9l4-6h6l4 6H5Zm0 6 4 6h6l4-6H5Z"/>'}];function xe(){return`
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M3.5 6.5A2 2 0 0 1 5.5 4.5h4l2 2h7A2 2 0 0 1 20.5 8.5v9A2 2 0 0 1 18.5 19.5h-13a2 2 0 0 1-2-2v-11Z"/>
      <path d="M7 11h10M7 15h7"/>
    </svg>`}function we(){return`
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="m7 3 5 8H2l5-8Z"/>
      <rect x="13.5" y="3.5" width="7" height="7" rx="1"/>
      <circle cx="16.5" cy="17" r="4"/>
    </svg>`}function ye(){return`
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <circle cx="5" cy="12" r="1.5"/>
      <circle cx="12" cy="12" r="1.5"/>
      <circle cx="19" cy="12" r="1.5"/>
    </svg>`}function ie(e){return`<svg viewBox="0 0 24 24" aria-hidden="true">${e}</svg>`}function ve(){if(document.getElementById(J))return;const e=document.createElement("style");e.id=J,e.textContent=`
    .better-excalidraw-page-button {
      position: fixed;
      z-index: 20;
      width: 40px;
      height: 40px;
      display: grid;
      place-items: center;
      padding: 0;
      border: 0;
      border-radius: 10px;
      color: var(--icon-fill-color, #1b1b1f);
      background: var(--island-bg-color, #fff);
      box-shadow: var(--shadow-island, 0 1px 4px rgba(0, 0, 0, 0.18));
      cursor: pointer;
      transition: background-color 120ms ease, color 120ms ease, transform 120ms ease;
    }
    .better-excalidraw-page-button:hover {
      color: var(--color-primary, #6965db);
      background: var(--button-hover-bg, #f1f0ff);
    }
    .better-excalidraw-page-button:active { transform: scale(.96); }
    .better-excalidraw-page-button:focus-visible {
      outline: 2px solid var(--color-primary, #6965db);
      outline-offset: 2px;
    }
    .better-excalidraw-page-button svg {
      width: 22px;
      height: 22px;
      fill: none;
      stroke: currentColor;
      stroke-width: 1.7;
      stroke-linecap: round;
      stroke-linejoin: round;
    }
    #${T} { top: 68px; left: 16px; }
    #${f} { top: 12px; right: 62px; }
    #${w} { top: 12px; right: 16px; }
    #${f}[aria-expanded="true"] {
      color: var(--color-primary, #6965db);
      background: var(--button-active-bg, #e9e7ff);
    }
    #${f}[aria-pressed="true"] {
      color: var(--color-primary, #6965db);
      background: var(--button-active-bg, #e9e7ff);
    }
    #${E} {
      position: fixed;
      z-index: 21;
      width: 310px;
      max-height: min(620px, calc(100vh - 90px));
      overflow-y: auto;
      padding: 10px;
      border: 1px solid var(--default-border-color, rgba(0, 0, 0, .12));
      border-radius: 12px;
      color: var(--text-primary-color, #1b1b1f);
      background: var(--island-bg-color, #fff);
      box-shadow: var(--shadow-island, 0 6px 24px rgba(0, 0, 0, .18));
      animation: better-excalidraw-panel-in 120ms ease-out;
    }
    #${w}[aria-expanded="true"] {
      color: var(--color-primary, #6965db);
      background: var(--button-active-bg, #e9e7ff);
    }
    #${I} {
      position: fixed;
      z-index: 21;
      width: 230px;
      padding: 7px;
      border: 1px solid var(--default-border-color, rgba(0, 0, 0, .12));
      border-radius: 12px;
      color: var(--text-primary-color, #1b1b1f);
      background: var(--island-bg-color, #fff);
      box-shadow: var(--shadow-island, 0 6px 24px rgba(0, 0, 0, .18));
      animation: better-excalidraw-panel-in 120ms ease-out;
    }
    @keyframes better-excalidraw-panel-in {
      from { opacity: 0; transform: translateY(-4px) scale(.98); }
      to { opacity: 1; transform: translateY(0) scale(1); }
    }
    .better-excalidraw-shape-heading {
      margin: 5px 4px 7px;
      color: var(--text-secondary-color, #6b6b73);
      font: 600 12px/16px system-ui, sans-serif;
    }
    .better-excalidraw-shape-grid {
      display: grid;
      grid-template-columns: repeat(5, 1fr);
      gap: 6px;
      margin-bottom: 10px;
    }
    .better-excalidraw-shape-option {
      min-width: 0;
      height: 50px;
      display: grid;
      place-items: center;
      padding: 0;
      border: 0;
      border-radius: 8px;
      color: var(--icon-fill-color, #1b1b1f);
      background: transparent;
      cursor: pointer;
    }
    .better-excalidraw-shape-option:hover,
    .better-excalidraw-shape-option:focus-visible {
      color: var(--color-primary, #6965db);
      background: var(--button-hover-bg, #f1f0ff);
      outline: 0;
    }
    .better-excalidraw-shape-option svg {
      width: 28px;
      height: 28px;
      fill: none;
      stroke: currentColor;
      stroke-width: 1.6;
      stroke-linejoin: round;
    }
    .better-excalidraw-operation-option {
      width: 100%;
      min-height: 38px;
      display: grid;
      grid-template-columns: 24px 1fr auto;
      align-items: center;
      gap: 9px;
      padding: 7px 9px;
      border: 0;
      border-radius: 8px;
      color: inherit;
      background: transparent;
      cursor: pointer;
      text-align: left;
      font: 500 13px/18px system-ui, sans-serif;
    }
    .better-excalidraw-operation-option:hover,
    .better-excalidraw-operation-option:focus-visible {
      color: var(--color-primary, #6965db);
      background: var(--button-hover-bg, #f1f0ff);
      outline: 0;
    }
    .better-excalidraw-operation-option svg {
      width: 20px;
      height: 20px;
      fill: none;
      stroke: currentColor;
      stroke-width: 1.7;
      stroke-linecap: round;
      stroke-linejoin: round;
    }
    .better-excalidraw-operation-shortcut {
      color: var(--text-secondary-color, #777780);
      font-size: 11px;
      font-weight: 500;
    }
    html.better-excalidraw-drawing .excalidraw canvas {
      cursor: crosshair !important;
    }
    #${C} {
      position: fixed;
      z-index: 19;
      pointer-events: none;
    }
    #${C} svg {
      width: 100%;
      height: 100%;
      overflow: visible;
    }
    #${C} svg > * {
      fill: rgba(105, 101, 219, .08);
      stroke: var(--color-primary, #6965db);
      stroke-width: 2;
      stroke-linejoin: round;
      vector-effect: non-scaling-stroke;
    }
    #${C} .shape-detail {
      fill: none;
    }
    #${H} {
      position: fixed;
      left: 50%;
      bottom: 24px;
      z-index: 21;
      padding: 8px 12px;
      border-radius: 9px;
      color: #fff;
      background: rgba(31, 31, 42, .88);
      box-shadow: 0 6px 20px rgba(0, 0, 0, .2);
      transform: translateX(-50%);
      pointer-events: none;
      font: 600 12px/16px system-ui, sans-serif;
    }
    #${z} {
      position: fixed;
      left: 50%;
      bottom: 28px;
      z-index: 2147483646;
      max-width: min(420px, calc(100vw - 32px));
      padding: 10px 14px;
      border-radius: 10px;
      color: #fff;
      background: rgba(31, 31, 42, .92);
      box-shadow: 0 8px 28px rgba(0, 0, 0, .24);
      transform: translateX(-50%);
      font: 600 13px/18px system-ui, sans-serif;
    }
    @media (max-width: 700px) {
      #${T} { top: 68px; left: 8px; }
      #${f} { right: 54px; }
      #${w} { right: 8px; }
    }
    @media (prefers-reduced-motion: reduce) {
      #${E}, #${I} { animation: none; }
      .better-excalidraw-page-button { transition: none; }
    }
  `,document.head.append(e)}function Ee(){const n=Array.from(document.querySelectorAll("button, [role='button']")).find(t=>{const r=`${t.getAttribute("aria-label")??""} ${t.getAttribute("title")??""}`,a=t.getBoundingClientRect();return a.width>0&&a.height>0&&/(^|\s)(矩形|Rectangle)(\s|$)/i.test(r)});if(!n)return null;let o=n.parentElement;for(let t=0;o&&t<7;t+=1,o=o.parentElement){const r=o.getBoundingClientRect();if(o.querySelectorAll("button, [role='button']").length>=8&&r.width>=320&&r.height>=36&&r.height<=80)return{referenceButton:n,toolbar:o}}return null}function Ie(e){return`${e.getAttribute("aria-label")??""} ${e.getAttribute("title")??""}`.trim()}function ke(){const e=Array.from(document.querySelectorAll(".excalidraw button, .excalidraw [role='button']")).filter(n=>{if(n.id===T||n.id===f||n.id===w)return!1;const o=n.getBoundingClientRect();return o.width>=30&&o.width<=56&&o.height>=30&&o.height<=56&&o.left>=0&&o.left<=90&&o.top>=0&&o.top<=90});return e.find(n=>/menu|菜单/i.test(Ie(n)))??e.sort((n,o)=>{const t=n.getBoundingClientRect(),r=o.getBoundingClientRect();return t.left+t.top-(r.left+r.top)})[0]??null}function G(e,n){const o=Math.round(n.width),t=Math.round(n.height);e.style.width=`${o}px`,e.style.height=`${t}px`;const r=Math.round(Math.min(22,Math.max(18,Math.min(o,t)*.55))),a=e.querySelector("svg");a&&(a.style.width=`${r}px`,a.style.height=`${r}px`)}function F(){const e=document.getElementById(T),n=document.getElementById(f),o=document.getElementById(w);if(!e||!n||!o)return;const t=ke();if(t){const a=t.getBoundingClientRect();G(e,a),e.style.left=`${Math.round(a.left)}px`,e.style.right="auto",e.style.top=`${Math.round(a.bottom+20)}px`}const r=Ee();if(r){const a=r.toolbar.getBoundingClientRect(),c=r.referenceButton.getBoundingClientRect(),d=Math.round(c.width),u=6,h=d*2+u,p=a.right+10,k=p+h<=window.innerWidth-8?p:a.left-h-10,D=k+d+u;for(const[y,A]of[[n,k],[o,D]])G(y,c),y.style.left=`${Math.max(8,A)}px`,y.style.right="auto",y.style.top=`${Math.max(8,c.top)}px`}for(const[a,c]of[[E,n],[I,o]]){const d=document.getElementById(a);if(!d)continue;const u=c.getBoundingClientRect(),h=a===E?310:230,p=d.getBoundingClientRect().width||h,x=Math.min(window.innerWidth-p-8,Math.max(8,u.right-p));d.style.left=`${x}px`,d.style.top=`${u.bottom+8}px`}}function V(e){document.getElementById(z)?.remove();const n=document.createElement("div");n.id=z,n.setAttribute("role","status"),n.textContent=e,document.body.append(n),window.setTimeout(()=>n.remove(),2600)}function L(){document.getElementById(E)?.remove(),document.getElementById(f)?.setAttribute("aria-expanded","false")}function $(){document.getElementById(I)?.remove(),document.getElementById(w)?.setAttribute("aria-expanded","false")}function Ae(e){$(),L();const n=document.createElement("div");n.id=E,n.setAttribute("role","dialog"),n.setAttribute("aria-label",s("extendedShapes")),n.innerHTML=`
    ${ae.map(o=>`
        <div class="better-excalidraw-shape-heading">${o.label}</div>
        <div class="better-excalidraw-shape-grid">
          ${o.shapes.map(t=>`
          <button class="better-excalidraw-shape-option" type="button" data-shape="${t.kind}" aria-label="${t.label}" title="${t.label}">
            ${ie(t.icon)}
          </button>`).join("")}
        </div>`).join("")}`,n.addEventListener("click",o=>{const t=o.target.closest("[data-shape]");if(!t)return;const r=t.dataset.shape;if(!r)return;const a=fe.find(c=>c.kind===r);a&&(e(a),L())}),document.body.append(n),document.getElementById(f)?.setAttribute("aria-expanded","true"),F()}function Se(e){L(),$();const n=document.createElement("div");n.id=I,n.setAttribute("role","menu"),n.setAttribute("aria-label",s("selectedShapeActions")),n.innerHTML=ge.map(o=>`
      <button class="better-excalidraw-operation-option" type="button" role="menuitem" data-operation="${o.operation}">
        <svg viewBox="0 0 24 24" aria-hidden="true">${o.icon}</svg>
        <span>${o.label}</span>
        <span class="better-excalidraw-operation-shortcut">${o.shortcut??""}</span>
      </button>`).join(""),n.addEventListener("click",o=>{const r=o.target.closest("[data-operation]")?.dataset.operation;r&&($(),e(r))}),document.body.append(n),document.getElementById(w)?.setAttribute("aria-expanded","true"),F()}function Q(e,n,o){if(document.body){if(ve(),!document.getElementById(T)){const t=document.createElement("button");t.id=T,t.className="better-excalidraw-page-button",t.type="button",t.title=s("openLocalWorkspace"),t.setAttribute("aria-label",s("openLocalWorkspace")),t.innerHTML=xe(),t.addEventListener("click",()=>{e.onOpenWorkspace().catch(r=>{V(r instanceof Error?r.message:String(r))})}),document.body.append(t)}if(!document.getElementById(f)){const t=document.createElement("button");t.id=f,t.className="better-excalidraw-page-button",t.type="button",t.title=s("extendedShapes"),t.setAttribute("aria-label",s("extendedShapes")),t.setAttribute("aria-expanded","false"),t.setAttribute("aria-pressed","false"),t.innerHTML=we(),t.addEventListener("click",n),document.body.append(t)}if(!document.getElementById(w)){const t=document.createElement("button");t.id=w,t.className="better-excalidraw-page-button",t.type="button",t.title=s("selectedShapeActions"),t.setAttribute("aria-label",s("selectedShapeActions")),t.setAttribute("aria-expanded","false"),t.innerHTML=ye(),t.addEventListener("click",o),document.body.append(t)}F()}}function Me(e){let n=0,o=null,t=null;const r=()=>{document.getElementById(C)?.remove()},a=()=>{o=null,t=null,r(),document.getElementById(H)?.remove(),document.documentElement.classList.remove("better-excalidraw-drawing"),document.getElementById(f)?.setAttribute("aria-pressed","false")},c=i=>{o=i,r(),document.documentElement.classList.add("better-excalidraw-drawing"),document.getElementById(f)?.setAttribute("aria-pressed","true"),document.getElementById(H)?.remove();const l=document.createElement("div");l.id=H,l.textContent=s("drawShapeHint",{shape:i.label}),document.body.append(l)},d=()=>{document.getElementById(E)?L():Ae(c)},u=i=>{e.onSelectionOperation(i).catch(l=>{V(l instanceof Error?l.message:String(l))})},h=()=>{o&&a(),document.getElementById(I)?$():Se(u)},p=()=>{window.cancelAnimationFrame(n),n=window.requestAnimationFrame(()=>Q(e,d,h))};Q(e,d,h);const x=new MutationObserver(p);x.observe(document.documentElement,{childList:!0,subtree:!0}),window.addEventListener("resize",p);const k=i=>{const l=i.target,m=document.getElementById(E),g=document.getElementById(f),M=document.getElementById(I),X=document.getElementById(w);m&&!m.contains(l)&&!g?.contains(l)&&L(),M&&!M.contains(l)&&!X?.contains(l)&&$(),o&&l instanceof Element&&!m?.contains(l)&&!g?.contains(l)&&l.closest(".excalidraw button, .excalidraw [role='button']")&&a()},D=i=>{i.key==="Escape"&&(o?a():(L(),$()))},y=i=>{if(!t)return null;let l=i.clientX,m=i.clientY;if(i.shiftKey){const Z=Math.max(Math.abs(l-t.x),Math.abs(m-t.y));l=t.x+Math.sign(l-t.x||1)*Z,m=t.y+Math.sign(m-t.y||1)*Z}const g=Math.min(t.x,l),M=Math.min(t.y,m),X=Math.abs(l-t.x),K=Math.abs(m-t.y);return{centerX:g+X/2,centerY:M+K/2,height:K,left:g,top:M,width:X}},A=i=>{if(!o)return;const l=y(i);if(!l)return;let m=document.getElementById(C);m||(m=document.createElement("div"),m.id=C,m.innerHTML=ie(o.icon),document.body.append(m)),m.style.left=`${l.left}px`,m.style.top=`${l.top}px`,m.style.width=`${Math.max(1,l.width)}px`,m.style.height=`${Math.max(1,l.height)}px`},O=i=>{!o||i.button!==0||!(i.target instanceof HTMLCanvasElement)||(i.preventDefault(),i.stopImmediatePropagation(),t={x:i.clientX,y:i.clientY,pointerId:i.pointerId},A(i))},_=i=>{!t||i.pointerId!==t.pointerId||(i.preventDefault(),i.stopImmediatePropagation(),A(i))},S=i=>{if(!t||!o||i.pointerId!==t.pointerId)return;i.preventDefault(),i.stopImmediatePropagation();const l=y(i),m=o;a(),!(!l||l.width<4||l.height<4)&&e.onDrawShape(m.kind,l).catch(g=>{V(g instanceof Error?g.message:String(g))})},P=i=>{!t||i.pointerId!==t.pointerId||(i.preventDefault(),i.stopImmediatePropagation(),a())};return document.addEventListener("click",k,!0),document.addEventListener("keydown",D,!0),document.addEventListener("pointerdown",O,!0),document.addEventListener("pointermove",_,!0),document.addEventListener("pointerup",S,!0),document.addEventListener("pointercancel",P,!0),()=>{x.disconnect(),window.cancelAnimationFrame(n),window.removeEventListener("resize",p),document.removeEventListener("click",k,!0),document.removeEventListener("keydown",D,!0),document.removeEventListener("pointerdown",O,!0),document.removeEventListener("pointermove",_,!0),document.removeEventListener("pointerup",S,!0),document.removeEventListener("pointercancel",P,!0),a(),document.getElementById(T)?.remove(),document.getElementById(f)?.remove(),document.getElementById(E)?.remove(),document.getElementById(w)?.remove(),document.getElementById(I)?.remove()}}const q=".excalidraw",Be="files-db",Ce=["files-store","files","binaryFiles"],R="better-excalidraw-save-overlay",ee="better-excalidraw-save-style",ce="application/vnd.excalidraw.clipboard+json";function te(e){return e instanceof Error?e.message:String(e)}function N(e,n){if(!e)return n;try{return JSON.parse(e)}catch{return n}}function Te(e){return!e||typeof e!="object"?!1:Array.isArray(e.elements)}async function De(e,n){const o=JSON.parse(n);if(!Te(o))throw new Error(s("invalidExcalidrawFile"));const t=document.querySelector(q);if(!t)throw new Error(s("excalidrawCanvasNotFoundRefresh"));const r=new File([n],e,{type:"application/json",lastModified:Date.now()}),a=new DataTransfer;a.items.add(r);for(const c of["dragenter","dragover","drop"])t.dispatchEvent(new DragEvent(c,{bubbles:!0,cancelable:!0,dataTransfer:a}));return await new Promise(c=>window.setTimeout(c,350)),se()}function Pe(){return new Promise(e=>{const n=indexedDB.open(Be);n.onerror=()=>e(null),n.onblocked=()=>e(null),n.onupgradeneeded=()=>{n.transaction?.abort(),e(null)},n.onsuccess=()=>e(n.result)})}async function Le(e){if(e.size===0)return{};const n=await Pe();if(!n)return{};const o=Ce.find(t=>n.objectStoreNames.contains(t));if(!o)return n.close(),{};try{return await new Promise((t,r)=>{const a={},c=n.transaction(o,"readonly"),d=c.objectStore(o).openCursor();d.onerror=()=>r(d.error),d.onsuccess=()=>{const u=d.result;if(!u)return;const h=String(u.key);e.has(h)&&(a[h]=u.value),u.continue()},c.oncomplete=()=>t(a),c.onerror=()=>r(c.error),c.onabort=()=>r(c.error)})}finally{n.close()}}function $e(e){const n=new Set;for(const o of e){if(!o||typeof o!="object")continue;const t=o.fileId;typeof t=="string"&&t&&n.add(t)}return n}function _e(e,n=s("savingCurrent")){if(document.getElementById(R)?.remove(),!e)return;if(!document.getElementById(ee)){const a=document.createElement("style");a.id=ee,a.textContent=`
      @keyframes better-excalidraw-spin {
        to { transform: rotate(360deg); }
      }
      #${R} {
        position: fixed;
        inset: 0;
        z-index: 2147483647;
        display: grid;
        place-items: center;
        background: rgba(20, 20, 28, 0.24);
        backdrop-filter: blur(2px);
        pointer-events: all;
      }
      #${R} > div {
        display: flex;
        align-items: center;
        gap: 12px;
        min-width: 210px;
        padding: 15px 18px;
        border: 1px solid rgba(255, 255, 255, 0.34);
        border-radius: 14px;
        color: #fff;
        background: rgba(31, 31, 42, 0.9);
        box-shadow: 0 14px 42px rgba(0, 0, 0, 0.28);
        font: 600 14px/20px Inter, system-ui, sans-serif;
      }
      #${R} span {
        width: 22px;
        height: 22px;
        flex: 0 0 auto;
        border: 3px solid rgba(255, 255, 255, 0.28);
        border-top-color: #a8a5ff;
        border-radius: 50%;
        animation: better-excalidraw-spin 0.75s linear infinite;
      }
    `,document.head.append(a)}const o=document.createElement("div");o.id=R,o.setAttribute("role","status"),o.setAttribute("aria-live","polite");const t=document.createElement("div"),r=document.createElement("span");r.setAttribute("aria-hidden","true"),t.append(r,document.createTextNode(n)),o.append(t),document.body.append(o)}async function se(){const e=N(localStorage.getItem("excalidraw"),[]),n=N(localStorage.getItem("excalidraw-state"),{}),o=await Le($e(e));return JSON.stringify({type:"excalidraw",version:2,source:"https://excalidraw.com",elements:e,appState:n,files:o},null,2)}function le(e){const n=e.zoom;if(typeof n=="number"&&n>0)return n;if(n&&typeof n=="object"){const o=n.value;if(typeof o=="number"&&o>0)return o}return 1}async function Re(e,n){const o=document.querySelector(q),t=document.elementFromPoint(n.centerX,n.centerY),r=t instanceof HTMLCanvasElement?t:o?.querySelector("canvas");if(!o||!r)throw new Error(s("excalidrawCanvasNotFound"));const a=N(localStorage.getItem("excalidraw-state"),{}),c=le(a),d=be(e,a,n.width/c,n.height/c),u=JSON.stringify({type:"excalidraw/clipboard",elements:d,files:{}});o.hasAttribute("tabindex")||o.setAttribute("tabindex","-1"),o.focus({preventScroll:!0});const h={bubbles:!0,cancelable:!0,clientX:n.centerX,clientY:n.centerY,pointerId:1,pointerType:"mouse"};r.dispatchEvent(new PointerEvent("pointermove",h)),r.dispatchEvent(new MouseEvent("mousemove",{bubbles:!0,cancelable:!0,clientX:n.centerX,clientY:n.centerY}));const p=new DataTransfer;p.setData("application/vnd.excalidraw.clipboard+json",u),p.setData("text/plain",u),document.dispatchEvent(new ClipboardEvent("paste",{bubbles:!0,cancelable:!0,clipboardData:p})),await new Promise(x=>window.setTimeout(x,80))}function j(){const e=document.querySelector(q);if(!e)throw new Error(s("excalidrawCanvasNotFound"));return e.hasAttribute("tabindex")||e.setAttribute("tabindex","-1"),e.focus({preventScroll:!0}),e}async function de(){const e=j(),n=new DataTransfer;e.dispatchEvent(new ClipboardEvent("copy",{bubbles:!0,cancelable:!0,clipboardData:n})),await Promise.resolve();const o=n.getData(ce)||n.getData("text/plain");if(!o)throw new Error(s("selectShapes"));const t=JSON.parse(o),r=(t.elements??[]).filter(p=>!p.isDeleted);if(r.length===0)throw new Error(s("selectShapes"));const c=N(localStorage.getItem("excalidraw-state"),{}).selectedElementIds??{},d=r.filter(p=>c[p.id]);if(d.length>0)return{allElements:r,files:t.files??{},selectedElements:d};const u=new Set(r.map(p=>p.id)),h=r.filter(p=>!p.containerId||!u.has(p.containerId));return{allElements:r,files:t.files??{},selectedElements:h.length>0?h:r}}async function W(){return(await de()).selectedElements}function Y({code:e,key:n,primary:o=!1,shiftKey:t=!1}){const r=j(),a=/Mac|iPhone|iPad|iPod/i.test(navigator.platform),c={bubbles:!0,cancelable:!0,code:e,key:n,ctrlKey:o&&!a,metaKey:o&&a,shiftKey:t};r.dispatchEvent(new KeyboardEvent("keydown",c)),r.dispatchEvent(new KeyboardEvent("keyup",c))}function pe(e,n,o,t,r){const a=Math.cos(r),c=Math.sin(r),d=e-o,u=n-t;return{x:o+d*a-u*c,y:t+d*c+u*a}}function Ne(e){const n=e.x+e.width/2,o=e.y+e.height/2,t=e.angle??0,a=[[e.x,e.y],[e.x+e.width,e.y],[e.x+e.width,e.y+e.height],[e.x,e.y+e.height]].map(([c,d])=>pe(c,d,n,o,t));return{minX:Math.min(...a.map(c=>c.x)),minY:Math.min(...a.map(c=>c.y)),maxX:Math.max(...a.map(c=>c.x)),maxY:Math.max(...a.map(c=>c.y))}}function Oe(e,n,o,t){const r=le(o),a=typeof o.scrollX=="number"?o.scrollX:0,c=typeof o.scrollY=="number"?o.scrollY:0,d=t.getBoundingClientRect();return{x:d.left+(e+a)*r,y:d.top+(n+c)*r}}async function ne(e){const n=await de(),{allElements:o,files:t,selectedElements:r}=n;if(!r[0])throw new Error(s("selectShapes"));if(r.some(i=>i.locked||i.elbowed||i.type==="frame"||i.type==="magicframe"))throw new Error(s("selectionCannotRotate"));const a=j(),c=a.querySelector("canvas.excalidraw__canvas.interactive")??a.querySelector("canvas");if(!c)throw new Error(s("interactiveCanvasNotFound"));const d=N(localStorage.getItem("excalidraw-state"),{}),u=e?Math.PI/2:-Math.PI/2,h=r.map(Ne),p=Math.min(...h.map(i=>i.minX)),x=Math.min(...h.map(i=>i.minY)),k=Math.max(...h.map(i=>i.maxX)),D=Math.max(...h.map(i=>i.maxY)),y=(p+k)/2,A=(x+D)/2,O=o.map(i=>{const l=i.x+i.width/2,m=i.y+i.height/2,g=pe(l,m,y,A,u),M=((i.angle??0)+u+Math.PI*2)%(Math.PI*2);return{...i,x:i.x+g.x-l,y:i.y+g.y-m,angle:M}}),_=JSON.stringify({type:"excalidraw/clipboard",elements:O,files:t});Y({code:"Delete",key:"Delete"}),await new Promise(i=>window.requestAnimationFrame(()=>i()));const S=Oe(y,A,d,c);c.dispatchEvent(new PointerEvent("pointermove",{bubbles:!0,cancelable:!0,clientX:S.x,clientY:S.y,pointerId:1,pointerType:"mouse"})),c.dispatchEvent(new MouseEvent("mousemove",{bubbles:!0,cancelable:!0,clientX:S.x,clientY:S.y}));const P=new DataTransfer;P.setData(ce,_),P.setData("text/plain",_),document.dispatchEvent(new ClipboardEvent("paste",{bubbles:!0,cancelable:!0,clipboardData:P})),await new Promise(i=>window.setTimeout(i,80))}async function Xe(e){switch(e){case"duplicate":await W(),Y({code:"KeyD",key:"d",primary:!0});return;case"flipHorizontal":await W(),Y({code:"KeyH",key:"H",shiftKey:!0});return;case"flipVertical":await W(),Y({code:"KeyV",key:"V",shiftKey:!0});return;case"rotateClockwise":await ne(!0);return;case"rotateCounterclockwise":await ne(!1)}}async function He(){const e=await chrome.runtime.sendMessage({type:"BETTER_EXCALIDRAW_OPEN_SIDE_PANEL"});if(!e.ok)throw new Error(e.error)}chrome.runtime.onMessage.addListener((e,n,o)=>e.type==="BETTER_EXCALIDRAW_PING"?(o({ok:!0}),!1):e.type==="BETTER_EXCALIDRAW_LOAD_CANVAS"?(De(e.fileName,e.content).then(t=>o({ok:!0,content:t})).catch(t=>o({ok:!1,error:te(t)})),!0):e.type==="BETTER_EXCALIDRAW_CAPTURE_CANVAS"?(se().then(t=>o({ok:!0,content:t})).catch(t=>o({ok:!1,error:te(t)})),!0):(e.type==="BETTER_EXCALIDRAW_SET_SAVE_STATUS"&&(_e(e.visible,e.text),o({ok:!0})),!1));Me({onDrawShape:Re,onOpenWorkspace:He,onSelectionOperation:Xe});
//# sourceMappingURL=content.ts-if88aW2u.js.map
